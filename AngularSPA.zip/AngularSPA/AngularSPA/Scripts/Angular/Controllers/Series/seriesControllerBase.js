﻿(function () {

	angular.module("appModule")
		.service("seriesControllerBase", ["$routeParams", "controllerBase",
			function ($routeParams, controllerBase) {
				return {
					initialize: function (scope, customizer) {
						var api = {
							form: "Scripts/Angular/Views/Series/form.html",
							hint: "series_id=GNPCA",
							results: "Scripts/Angular/Views/Common/seriesResults.html",
							initialOrderByColumn: "id",
						};
						if (customizer != null) {
							customizer(api);
						};

						controllerBase.initializeApi(scope, api);

						scope.onFormSubmit = function () {
							controllerBase.redirect(scope.fredPath + "/id/" + scope.seriesId);
						};
						scope.$parent.seriesId = $routeParams.seriesId != null ? $routeParams.seriesId : null;
					},
					fetch: function (scope, canFetch, arguments) {
						canFetch = canFetch != null ? canFetch : scope.seriesId != null;
						arguments = arguments != null ? arguments : { series_Id: scope.seriesId };
						if (canFetch) {
							controllerBase.fetch(scope, "series" + scope.fredPath, arguments);
						};
					}
				}
			}
		]);

}());