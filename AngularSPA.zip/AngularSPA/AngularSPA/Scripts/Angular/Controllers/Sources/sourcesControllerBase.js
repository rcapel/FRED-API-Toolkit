﻿(function () {

	angular.module("appModule")
		.service("sourcesControllerBase", ["$routeParams", "controllerBase",
			function ($routeParams, controllerBase) {
				return {
					initialize: function (scope, customizer) {
						var api = {
							form: "Scripts/Angular/Views/Sources/form.html",
							hint: "source_id=1",
							results: "Scripts/Angular/Views/Common/sourcesResults.html",
							initialOrderByColumn: "id",
						};
						if (customizer != null) {
							customizer(api);
						};

						controllerBase.initializeApi(scope, api);

						scope.onFormSubmit = function () {
							controllerBase.redirect(scope.fredPath + "/id/" + scope.sourceId);
						};
						scope.$parent.sourceId = $routeParams.sourceId != null ? parseInt($routeParams.sourceId) : null;
					},
					fetch: function (scope, canFetch, arguments) {
						canFetch = canFetch != null ? canFetch : scope.sourceId != null;
						arguments = arguments != null ? arguments : { source_id: scope.sourceId };
						if (canFetch) {
							controllerBase.fetch(scope, "sources" + scope.fredPath, arguments);
						};
					}
				}
			}
		]);

}());