﻿(function () {

	angular.module("appModule")
		.service("controllerBase", ["$location", "orderByService", "httpService",
			function ($location, orderByService, httpService) {
				return {
					initializeApi: function (scope, api) {
						api.orderByEnabled = api.initialOrderByColumn != null;
						if (api.orderByEnabled) {
							orderByService.initialize(scope, api.initialOrderByColumn, api.ignoreOrderByColumns);
						}
						scope.api = api;
					},
					redirect: function (path) {
						if ($location.path() != path) {
							$location.path(path);
						}
					},
					fetch: function (scope, path, arguments) {
						scope.column = scope.api.initialOrderByColumn;
						scope.reverse = false;
						httpService.post(path, arguments)
							.then(
								function (response) {
									scope.response = response.data;
									scope.container = response.data.container;
								},
								function (response) {
									scope.error = response;
								}
							);
					}
				}
			}
		]);

}());
