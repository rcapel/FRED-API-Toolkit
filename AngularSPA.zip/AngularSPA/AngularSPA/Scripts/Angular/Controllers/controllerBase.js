﻿(function () {

	angular.module("appModule")
		.service("controllerBase", ["$location", "orderByService", "httpService",
			function ($location, orderByService, httpService) {
				return {
					initializeApi: function (scope, api) {
						api.urlExtension = scope.fredPath;
						api.orderByEnabled = api.initialOrderByColumn != null;
						if (api.orderByEnabled) {
							orderByService.initialize(scope, api.initialOrderByColumn, api.ignoreOrderByColumns);
						}
						scope.api = api;
					},
					redirect: function (path) {
						if ($location.path() != path) {
							$location.path(path);
						}
					},
					fetch: function (scope, arguments) {
						scope.column = scope.api.initialOrderByColumn;
						scope.reverse = false;
						scope.api.callService(
							httpService,
							arguments,
							scope.api.urlExtension)
							.then(
								function (response) {
									scope.response = response.data;
									scope.container = response.data.container;
								},
								function (response) {
									scope.error = response;
								}
							);
					}
				}
			}
		]);

}());
