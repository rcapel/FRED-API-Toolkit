﻿(function () {

	angular.module("appModule")
		.service("categoriesControllerBase", ["$routeParams", "controllerBase",
			function ($routeParams, controllerBase) {
				return {
					initialize: function (scope, customizer) {
						var api = {
							form: "Scripts/Angular/Views/Categories/form.html",
							hint: "category_id=125",
							results: "Scripts/Angular/Views/Common/categoriesResults.html",
							callService: function (httpService, arguments, urlExtension) {
								return httpService.post("categories" + urlExtension, arguments);
							},
							initialOrderByColumn: "id"
						};
						if (customizer != null) {
							customizer(api);
						};

						controllerBase.initializeApi(scope, api);

						scope.onFormSubmit = function () {
							controllerBase.redirect(scope.fredPath + "/id/" + scope.categoryId);
						};
						scope.$parent.categoryId = $routeParams.categoryId != null ? parseInt($routeParams.categoryId) : null;
					},
					fetch: function (scope, canFetch, arguments) {
						canFetch = canFetch != null ? canFetch : scope.categoryId != null;
						arguments = arguments != null ? arguments : { category_id: scope.categoryId };
						if (canFetch) {
							controllerBase.fetch(scope, arguments);
						};
					}
				}
			}
		]);

}());