﻿(function () {

	angular.module("appModule")
	  .controller("mainController", ["$scope",
		function ($scope) {

		}
	  ]);

}());