﻿"use strict";
(function () {

	angular.module("appModule")
	  .controller("mainController", ["$scope", "$location",
		function ($scope, $location) {

		}
	  ]);

}());