﻿(function () {

	angular.module("appModule")
	  .controller("releasesController", ["$scope", "$location", "releasesService",
		function ($scope, $location, releasesService) {

			var api = releasesService.create($location.path(), $scope);
			$scope.form = api.form;
			$scope.hint = api.hint;
			$scope.results = api.results;
			$scope.orderByEnabled = api.initialOrderByColumn != null;
			$scope.fredPath = $location.path();

			$scope.fetch = function () {
				$scope.column = api.initialOrderByColumn;
				$scope.reverse = false;
				api.callService(
					{
						releaseId: $scope.releaseId,
						tagNames: $scope.tagNames
					},
					api.urlExtension)
					.then(onFetchComplete, onError);
			}

			var onFetchComplete = function (response) {
				$scope.response = response.data;
				$scope.container = response.data.container;
			}

			var onError = function (response) {
				$scope.error = response;
			}

		}
	  ]);

}());