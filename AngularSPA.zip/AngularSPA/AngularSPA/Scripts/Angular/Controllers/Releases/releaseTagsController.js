﻿(function () {

	angular.module("appModule")
		.controller("releaseTagsController", ["$scope", "releasesControllerBase",
			function ($scope, releasesControllerBase) {
				$scope.fredPath = "/release/tags";
				releasesControllerBase.initialize($scope, function (api) {
					api.hint = "release_id=86";
					api.results = "Scripts/Angular/Views/Common/tagsResults.html";
					api.initialOrderByColumn = "name";
				});
				releasesControllerBase.fetch($scope);
			}
		]);

}());