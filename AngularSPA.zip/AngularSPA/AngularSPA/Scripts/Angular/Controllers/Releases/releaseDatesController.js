﻿"use strict";
(function () {

	angular.module("appModule")
		.controller("releaseDatesController", ["$scope", "releasesControllerBase",
			function ($scope, releasesControllerBase) {
				$scope.fredPath = "/release/dates";
				releasesControllerBase.initialize($scope, function (api) {
					api.hint = "release_id=82";
					api.results = "/Views/Releases/releaseDatesResults.html";
					api.initialOrderByColumn = "date";
					api.ignoreOrderByColumns = ["release_id"];
				});
				releasesControllerBase.fetch($scope);
			}
		]);

}());