﻿"use strict";
(function () {

	angular.module("appModule")
		.controller("releasesController", ["$scope", "releasesControllerBase",
			function ($scope, releasesControllerBase) {
				$scope.fredPath = "/releases";
				releasesControllerBase.initialize($scope, function (api) {
					api.form = "/Views/Common/form.html";
				});
				releasesControllerBase.fetch($scope, true, "");
			}
		]);

}());