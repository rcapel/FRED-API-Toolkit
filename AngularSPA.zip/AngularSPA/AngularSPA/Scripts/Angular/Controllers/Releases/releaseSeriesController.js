﻿(function () {

	angular.module("appModule")
		.controller("releaseSeriesController", ["$scope", "releasesControllerBase",
			function ($scope, releasesControllerBase) {
				$scope.fredPath = "/release/series";
				releasesControllerBase.initialize($scope, function (api) {
					api.hint = "release_id=51";
					api.results = "Scripts/Angular/Views/Common/seriesResults.html";
				});
				releasesControllerBase.fetch($scope);
			}
		]);

}());