﻿(function () {

	angular.module("appModule")
		.controller("releaseController", ["$scope", "releasesControllerBase",
			function ($scope, releasesControllerBase) {
				$scope.fredPath = "/release";
				releasesControllerBase.initialize($scope, function (api) {
					api.hint = "release_id=53";
					api.initialOrderByColumn = null;
				});
				releasesControllerBase.fetch($scope);
			}
		]);

}());