﻿"use strict";
(function () {

	angular.module("appModule")
		.controller("releasesDatesController", ["$scope", "releasesControllerBase",
			function ($scope, releasesControllerBase) {
				$scope.fredPath = "/releases/dates";
				releasesControllerBase.initialize($scope, function (api) {
					api.form = "/Views/Common/form.html";
					api.results = "/Views/Releases/releasesDatesResults.html";
					api.initialOrderByColumn = "release_id";
				});
				releasesControllerBase.fetch($scope, true, "");
			}
		]);

}());