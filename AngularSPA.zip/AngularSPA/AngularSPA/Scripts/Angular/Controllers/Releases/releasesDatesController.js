﻿(function () {

	angular.module("appModule")
		.controller("releasesDatesController", ["$scope", "releasesControllerBase",
			function ($scope, releasesControllerBase) {
				$scope.fredPath = "/releases/dates";
				releasesControllerBase.initialize($scope, function (api) {
					api.form = "Scripts/Angular/Views/Common/form.html";
					api.results = "Scripts/Angular/Views/Releases/releasesDatesResults.html";
					api.initialOrderByColumn = "release_id";
				});
				releasesControllerBase.fetch($scope, true, {});
			}
		]);

}());