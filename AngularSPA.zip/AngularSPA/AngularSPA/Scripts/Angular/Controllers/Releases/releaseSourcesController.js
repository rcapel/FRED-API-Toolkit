﻿(function () {

	angular.module("appModule")
		.controller("releaseSourcesController", ["$scope", "releasesControllerBase",
			function ($scope, releasesControllerBase) {
				$scope.fredPath = "/release/sources";
				releasesControllerBase.initialize($scope, function (api) {
					api.hint = "release_id=51";
					api.results = "Scripts/Angular/Views/Common/sourcesResults.html";
				});
				releasesControllerBase.fetch($scope);
			}
		]);

}());