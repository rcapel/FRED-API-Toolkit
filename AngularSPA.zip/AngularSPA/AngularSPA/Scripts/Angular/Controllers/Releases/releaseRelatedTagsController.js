﻿"use strict";
(function () {

	angular.module("appModule")
		.controller("releaseRelatedTagsController", ["$scope", "$routeParams", "releasesControllerBase", "controllerBase",
			function ($scope, $routeParams, releasesControllerBase, controllerBase) {
				$scope.fredPath = "/release/related_tags";
				releasesControllerBase.initialize($scope, function (api) {
					api.form = "/Views/Releases/relatedTagsForm.html";
					api.results = "/Views/Common/tagsResults.html";
					api.initialOrderByColumn = "name";
				});

				// override initial default values
				$scope.onFormSubmit = function () {
					controllerBase.redirect($scope.fredPath + "/id/" + $scope.releaseId + "/tag_names/" + $scope.tagNames);
				};
				$scope.$parent.tagNames = $routeParams.tag_names != null ? $routeParams.tag_names : null;

				releasesControllerBase.fetch($scope,
					$scope.releaseId != null && $scope.tagNames != null,
					"id/" + $scope.releaseId + "/tag_names/" + $scope.tagNames);
			}
		]);

}());
