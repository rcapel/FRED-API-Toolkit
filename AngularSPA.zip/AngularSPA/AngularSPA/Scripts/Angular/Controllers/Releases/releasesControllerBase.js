﻿"use strict";
(function () {

	angular.module("appModule")
		.service("releasesControllerBase", ["$routeParams", "controllerBase",
			function ($routeParams, controllerBase) {
				return {
					initialize: function (scope, customizer) {
						var api = {
							form: "/Views/Releases/form.html",
							results: "/Views/Common/releasesResults.html",
							initialOrderByColumn: "id",
						};
						if (customizer != null) {
							customizer(api);
						};

						controllerBase.initializeApi(scope, api);

						scope.onFormSubmit = function () {
							controllerBase.redirect(scope.fredPath + "/id/" + scope.releaseId);
						};
						scope.$parent.releaseId = $routeParams.releaseId != null ? parseInt($routeParams.releaseId) : null;
					},
					fetch: function (scope, canFetch, urlExtension) {
						canFetch = canFetch != null ? canFetch : scope.releaseId != null;
						if (canFetch) {
							urlExtension = urlExtension != null ? (urlExtension.startsWith("/") ? "" : "/") + urlExtension : "/id/" + scope.releaseId;
							controllerBase.fetch(scope, "releases" + scope.fredPath + urlExtension);
						};
					}
				}
			}
		]);

}());