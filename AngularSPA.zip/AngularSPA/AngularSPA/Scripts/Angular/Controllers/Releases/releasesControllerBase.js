﻿(function () {

	angular.module("appModule")
		.service("releasesControllerBase", ["$routeParams", "controllerBase",
			function ($routeParams, controllerBase) {
				return {
					initialize: function (scope, customizer) {
						var api = {
							form: "Scripts/Angular/Views/Releases/form.html",
							results: "Scripts/Angular/Views/Common/releasesResults.html",
							callService: function (httpService, arguments, urlExtension) {
								return httpService.post("releases" + urlExtension, arguments);
							},
							initialOrderByColumn: "id",
						};
						if (customizer != null) {
							customizer(api);
						};

						controllerBase.initializeApi(scope, api);

						scope.onFormSubmit = function () {
							controllerBase.redirect(scope.fredPath + "/id/" + scope.releaseId);
						};
						scope.$parent.releaseId = $routeParams.releaseId != null ? parseInt($routeParams.releaseId) : null;
					},
					fetch: function (scope, canFetch, arguments) {
						canFetch = canFetch != null ? canFetch : scope.releaseId != null;
						arguments = arguments != null ? arguments : { release_id: scope.releaseId };
						if (canFetch) {
							controllerBase.fetch(scope, arguments);
						};
					}
				}
			}
		]);

}());