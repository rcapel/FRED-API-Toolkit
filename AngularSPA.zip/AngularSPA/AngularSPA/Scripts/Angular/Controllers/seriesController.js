﻿(function () {

	angular.module("appModule")
	  .controller("seriesController", ["$scope", "$location", "seriesService",
		function ($scope, $location, seriesService) {

			var api = seriesService.create($location.path(), $scope);
			$scope.form = api.form;
			$scope.hint = api.hint;
			$scope.results = api.results;
			$scope.orderByEnabled = api.initialOrderByColumn != null;
			$scope.fredPath = $location.path();

			$scope.fetch = function () {
				$scope.column = api.initialOrderByColumn;
				$scope.reverse = false;
				api.callService(
					{
						seriesId: $scope.seriesId,
						searchText: $scope.searchText,
						seriesSearchText: $scope.seriesSearchText,
						tagNames: $scope.tagNames
					},
					api.urlExtension)
					.then(onFetchComplete, onError);
			}

			var onFetchComplete = function (response) {
				$scope.response = response.data;
				$scope.container = response.data.container;
			}

			var onError = function (response) {
				$scope.error = response;
			}

		}
	  ]);

}());