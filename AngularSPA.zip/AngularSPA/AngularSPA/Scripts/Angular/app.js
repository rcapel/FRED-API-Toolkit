﻿(function () {

	var app = angular.module("appModule", ["ngRoute"]);

	app.config(function ($routeProvider) {
		$routeProvider
			.when("/main", {
				templateUrl: function () {
					return "Scripts/Angular/Views/main.html"
				},
      			controller: "mainController"
			})

			//
			// categories
			//
			.when("/category", {
				templateUrl: "Scripts/Angular/Views/Common/template.html",
				controller: "categoriesController"
			})
			.when("/category/:categoryPage", {
				templateUrl: "Scripts/Angular/Views/Common/template.html",
				controller: "categoriesController"
			})

			//
			// releases
			//
			.when("/releases", {
				templateUrl: "Scripts/Angular/Views/Common/template.html",
				controller: "releasesController"
			})
			.when("/releases/dates", {
				templateUrl: "Scripts/Angular/Views/Common/template.html",
				controller: "releasesController"
			})
			.when("/release", {
				templateUrl: "Scripts/Angular/Views/Common/template.html",
				controller: "releasesController"
			})
			.when("/release/:releasePage", {
				templateUrl: "Scripts/Angular/Views/Common/template.html",
				controller: "releasesController"
			})

			//
			// series
			//
			.when("/series", {
				templateUrl: "Scripts/Angular/Views/Common/template.html",
				controller: "seriesController"
			})
			.when("/series/:seriesPage", {
				templateUrl: "Scripts/Angular/Views/Common/template.html",
				controller: "seriesController"
			})
			.when("/series/search/:seriesPage", {
				templateUrl: "Scripts/Angular/Views/Common/template.html",
				controller: "seriesController"
			})

			//
			// sources
			//
			.when("/sources", {
				templateUrl: "Scripts/Angular/Views/Common/template.html",
				controller: "sourcesController"
			})
			.when("/source", {
				templateUrl: "Scripts/Angular/Views/Common/template.html",
				controller: "sourcesController"
			})
			.when("/source/releases", {
				templateUrl: "Scripts/Angular/Views/Common/template.html",
				controller: "sourcesController"
			})

			//
			// tags
			//
			.when("/tags", {
				templateUrl: "Scripts/Angular/Views/Common/template.html",
				controller: "tagsController"
			})
			.when("/related_tags", {
				templateUrl: "Scripts/Angular/Views/Common/template.html",
				controller: "tagsController"
			})
			.when("/tags/series", {
				templateUrl: "Scripts/Angular/Views/Common/template.html",
				controller: "tagsController"
			})

			//
			// default
			//
			.otherwise({
				redirectTo: "/main"
			})
	});

}());