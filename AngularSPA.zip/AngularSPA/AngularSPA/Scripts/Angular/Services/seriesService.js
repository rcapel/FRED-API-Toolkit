﻿(function () {

	angular.module("appModule").factory("seriesService", ["$location", "httpService", "orderByService", function ($location, httpService, orderByService) {

		var pathBase = "series/";
		var prototype = function () {
			return {
				form: "Scripts/Angular/Views/Series/form.html",
				hint: "series_id=GNPCA",
				results: "Scripts/Angular/Views/Common/seriesResults.html",
				callService: function (arguments, urlExtension) {
					var apiArguments = { series_id: arguments.seriesId };
					return httpService.post(pathBase + urlExtension, apiArguments);
				},
				initialOrderByColumn: "id"
			};
		}

		return {
			create: function (path, scope) {
				var api = prototype();
				var ignoreOrderByColumns;
				switch ($location.path()) {
					case "/series":
						api.initialOrderByColumn = null;
						break;
					case "/series/categories":
						api.hint = "series_id=EXJPUS";
						api.results = "Scripts/Angular/Views/Common/categoriesResults.html";
						break;
					case "/series/observations":
						api.results = "Scripts/Angular/Views/Series/observationsResults.html";
						api.initialOrderByColumn = "date";
						break;
					case "/series/release":
						api.hint = "series_id=IRA";
						api.results = "Scripts/Angular/Views/Common/releasesResults.html";
						break;
					case "/series/search":
						api.form = "Scripts/Angular/Views/Series/searchForm.html";
						api.hint = "search_text=monetary+service+index";
						api.callService = function (arguments, urlExtension) {
							var apiArguments = { search_text: arguments.searchText };
							return httpService.post(pathBase + urlExtension, apiArguments);
						};
						break;
					case "/series/search/tags":
						api.form = "Scripts/Angular/Views/Series/searchTagsForm.html";
						api.results = "Scripts/Angular/Views/Common/tagsResults.html";
						api.callService = function (arguments, urlExtension) {
							var apiArguments = { series_search_text: arguments.seriesSearchText };
							return httpService.post(pathBase + urlExtension, apiArguments);
						};
						api.initialOrderByColumn = "name";
						break;
					case "/series/search/related_tags":
						api.form = "Scripts/Angular/Views/Series/searchRelatedTagsForm.html";
						api.results = "Scripts/Angular/Views/Common/tagsResults.html";
						api.callService = function (arguments, urlExtension) {
							var apiArguments = { series_search_text: arguments.seriesSearchText, tag_names: arguments.tagNames };
							return httpService.post(pathBase + urlExtension, apiArguments);
						};
						api.initialOrderByColumn = "name";
						break;
					case "/series/tags":
						api.hint = "series_id=STLFSI";
						api.results = "Scripts/Angular/Views/Common/tagsResults.html";
						api.initialOrderByColumn = "name";
						break;
					case "/series/updates":
						api.form = "Scripts/Angular/Views/Common/form.html";
						api.callService = function (arguments, urlExtension) {
							return httpService.post(pathBase + urlExtension, {});
						};
						break;
					case "/series/vintagedates":
						api.results = "Scripts/Angular/Views/Series/datesResults.html";
						api.initialOrderByColumn = "toString()";
						break;
				}
				api.urlExtension = $location.path().substring(1);
				if (api.initialOrderByColumn != null) {
					orderByService.initialize(scope, api.initialOrderByColumn, ignoreOrderByColumns);
				}
				return api;
			}
		};

	}
	]);

}());