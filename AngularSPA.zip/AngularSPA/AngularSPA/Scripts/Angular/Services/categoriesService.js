﻿(function () {

	angular.module("appModule")
		.factory("categoriesService", ["$location", "httpService", "orderByService", function ($location, httpService, orderByService) {

			var pathBase = "categories/";
			var prototype = function () {
				return {
					form: "Scripts/Angular/Views/Categories/form.html",
					hint: "category_id=125",
					results: "Scripts/Angular/Views/Common/categoriesResults.html",
					callService: function (arguments, urlExtension) {
						var apiArguments = { category_id: arguments.categoryId };
						return httpService.post(pathBase + urlExtension, apiArguments);
					},
					initialOrderByColumn: "id"
			}
			};

			return {
				create: function (path, scope) {
					var api = prototype();
					var ignoreOrderByColumns;
					switch ($location.path()) {
						case "/category":
							api.initialOrderByColumn = null;
							break;
						case "/category/children":
							api.hint = "category_id=13";
							ignoreOrderByColumns = ["parent_id"];
							break;
						case "/category/related":
							api.hint = "category_id=32073";
							break;
						case "/category/series":
							api.results = "Scripts/Angular/Views/Common/seriesResults.html";
							break;
						case "/category/tags":
							api.results = "Scripts/Angular/Views/Common/tagsResults.html";
							api.initialOrderByColumn = "name";
							break;
						case "/category/related_tags":
							api.form = "Scripts/Angular/Views/Categories/relatedTagsForm.html";
							api.results = "Scripts/Angular/Views/Common/tagsResults.html";
							api.callService = function (arguments, urlExtension) {
								var apiArguments = { category_id: arguments.categoryId, tag_names: arguments.tagNames };
								return httpService.post(pathBase + urlExtension, apiArguments);
							};
							api.initialOrderByColumn = "name";
							break;
					}
					api.urlExtension = $location.path().substring(1);
					if (api.initialOrderByColumn != null) {
						orderByService.initialize(scope, api.initialOrderByColumn, ignoreOrderByColumns);
					}
					return api;
				}
			};

		}
		]);

}());