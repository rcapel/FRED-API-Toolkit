﻿(function () {

	angular.module("appModule").factory("sourcesService", ["$location", "httpService", "orderByService", function ($location, httpService, orderByService) {

		var pathBase = "sources/";
		var prototype = function () {
			return {
				form: "Scripts/Angular/Views/Sources/form.html",
				hint: "source_id=1",
				results: "Scripts/Angular/Views/Common/sourcesResults.html",
				callService: function (arguments, urlExtension) {
					var apiArguments = { source_id: arguments.sourceId };
					return httpService.post(pathBase + urlExtension, apiArguments);
				},
				initialOrderByColumn: "id"
			};
		}

		return {
			create: function (path, scope) {
				var api = prototype();
				var ignoreOrderByColumns;
				switch ($location.path()) {
					case "/sources":
						api.form = "Scripts/Angular/Views/Common/form.html";
						api.callService = function (arguments, urlExtension) {
							return httpService.post(pathBase + urlExtension, {});
						};
						break;
					case "/source":
						api.initialOrderByColumn = null;
						break;
					case "/source/releases":
						api.results = "Scripts/Angular/Views/Common/releasesResults.html";
						break;
				}
				api.urlExtension = $location.path().substring(1);
				if (api.initialOrderByColumn != null) {
					orderByService.initialize(scope, api.initialOrderByColumn, ignoreOrderByColumns);
				}
				return api;
			}
		};

	}
	]);

}());