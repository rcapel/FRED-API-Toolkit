﻿(function () {

	angular.module("appModule").factory("tagsService", ["$location", "httpService", "orderByService", function ($location, httpService, orderByService) {

		var pathBase = "tags/";
		var prototype = function () {
			return {
				form: "Scripts/Angular/Views/Tags/form.html",
				hint: "tag_id=1",
				results: "Scripts/Angular/Views/Common/tagsResults.html",
				callService: function (arguments, urlExtension) {
					var apiArguments = { tag_names: arguments.tagNames };
					return httpService.post(pathBase + urlExtension, apiArguments);
				},
				initialOrderByColumn: "name"
			};
		}

		return {
			create: function (path, scope) {
				var api = prototype();
				var ignoreOrderByColumns;
				switch ($location.path()) {
					case "/tags":
						api.form = "Scripts/Angular/Views/Common/form.html";
						api.callService = function (arguments, urlExtension) {
							return httpService.post(pathBase + urlExtension, {});
						};
						break;
					case "/related_tags":
						api.hint = "tag_names=monetary+aggregates;weekly";
						break;
					case "/tags/series":
						api.hint = "tag_names=slovenia;food;oecd";
						api.results = "Scripts/Angular/Views/Common/seriesResults.html";
						api.initialOrderByColumn = "id";
						break;
				}
				api.urlExtension = $location.path().substring(1);
				if (api.initialOrderByColumn != null) {
					orderByService.initialize(scope, api.initialOrderByColumn, ignoreOrderByColumns);
				}
				return api;
			}
		};

	}
	]);

}());