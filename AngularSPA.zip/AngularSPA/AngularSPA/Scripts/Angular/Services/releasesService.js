﻿(function () {

	angular.module("appModule")
		.factory("releasesService", ["$location", "httpService", "orderByService", function ($location, httpService, orderByService) {

			var pathBase = "releases/";
			var prototype = function () {
				return {
					form: "Scripts/Angular/Views/Releases/form.html",
					results: "Scripts/Angular/Views/Common/releasesResults.html",
					callService: function (arguments, urlExtension) {
						var apiArguments = { release_id: arguments.releaseId };
						return httpService.post(pathBase + urlExtension, apiArguments);
					},
					initialOrderByColumn: "id"
				}
			};

			return {
				create: function (path, scope) {
					var api = prototype();
					var ignoreOrderByColumns;
					switch ($location.path()) {
						case "/releases":
							api.form = "Scripts/Angular/Views/Common/form.html";
							api.callService = function (arguments, urlExtension) {
								return httpService.post(pathBase + urlExtension, {});
							};
							break;
						case "/releases/dates":
							api.form = "Scripts/Angular/Views/Common/form.html";
							api.results = "Scripts/Angular/Views/Releases/releasesDatesResults.html";
							api.callService = function (arguments, urlExtension) {
								return httpService.post(pathBase + urlExtension, {});
							};
							api.initialOrderByColumn = "release_id";
							break;
						case "/release":
							api.hint = "release_id=53";
							api.initialOrderByColumn = null;
							break;
						case "/release/dates":
							api.hint = "release_id=82";
							api.results = "Scripts/Angular/Views/Releases/releaseDatesResults.html";
							api.initialOrderByColumn = "date";
							ignoreOrderByColumns = ["release_id"];
							break;
						case "/release/series":
							api.hint = "release_id=51";
							api.results = "Scripts/Angular/Views/Common/seriesResults.html";
							break;
						case "/release/sources":
							api.hint = "release_id=51";
							api.results = "Scripts/Angular/Views/Common/sourcesResults.html";
							break;
						case "/release/tags":
							api.hint = "release_id=86";
							api.results = "Scripts/Angular/Views/Common/tagsResults.html";
							api.initialOrderByColumn = "name";
							break;
						case "/release/related_tags":
							api.form = "Scripts/Angular/Views/Releases/relatedTagsForm.html";
							api.results = "Scripts/Angular/Views/Common/tagsResults.html";
							api.callService = function (arguments, urlExtension) {
								var apiArguments = { release_id: arguments.releaseId, tag_names: arguments.tagNames };
								return httpService.post(pathBase + urlExtension, apiArguments);
							};
							api.initialOrderByColumn = "name";
							break;
					}
					api.urlExtension = $location.path().substring(1);
					if (api.initialOrderByColumn != null) {
						orderByService.initialize(scope, api.initialOrderByColumn, ignoreOrderByColumns);
					}
					return api;
				}
			};

		}
		]);

}());