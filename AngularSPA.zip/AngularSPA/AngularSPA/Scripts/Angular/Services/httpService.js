﻿(function () {

	angular.module("appModule")
		.factory("httpService", ["$http", function ($http) {

			return {
				post: function (url, arguments) {
					return $http({
						url: url,
						dataType: 'json',
						method: 'POST',
						data: arguments,
						headers: {
							"Content-Type": "application/json"
						}
					});
				}
			};

		}
		]);

}());