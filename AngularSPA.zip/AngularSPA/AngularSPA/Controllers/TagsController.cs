﻿using FRED.API.Tags.APIFacades;
using FRED.API.Tags.Arguments;
using FRED.API.Tags.Data;
using System.Web.Http;

namespace AngularSPA.Controllers
{
	[RoutePrefix("tags")]
	public class TagsController : FREDController
    {
		[Route("tags")]
		[HttpGet]
		public Response<TagContainer> FetchTags()
		{
			return Fetch<Tags, TagsArguments, TagContainer>(new TagsArguments());
		}

		[Route("related_tags/tag_names/{tagNames}")]
		[HttpGet]
		public Response<TagContainer> FetchRelatedTags(string tagNames)
		{
			return Fetch<RelatedTags, RelatedTagsArguments, TagContainer>(new RelatedTagsArguments { tag_names = tagNames });
		}

		[Route("tags/series/tag_names/{tagNames}")]
		[HttpGet]
		public Response<TagSeriesContainer> FetchTagsSeries(string tagNames)
		{
			return Fetch<TagsSeries, TagsSeriesArguments, TagSeriesContainer>(new TagsSeriesArguments { tag_names = tagNames });
		}

	}
}
