﻿using FRED.API.Tags.APIFacades;
using FRED.API.Tags.Arguments;
using FRED.API.Tags.Data;
using System.Net.Http;
using System.Web.Http;

namespace AngularSPA.Controllers
{
	[RoutePrefix("tags")]
	public class TagsController : FREDController
    {
		[Route("tags")]
		[HttpPost]
		public Response<TagContainer> FetchRelease(HttpRequestMessage request, [FromBody] TagsArguments arguments)
		{
			return Fetch<Tags, TagsArguments, TagContainer>(arguments);
		}

		[Route("related_tags")]
		[HttpPost]
		public Response<TagContainer> FetchReleases(HttpRequestMessage request, [FromBody] RelatedTagsArguments arguments)
		{
			return Fetch<RelatedTags, RelatedTagsArguments, TagContainer>(arguments);
		}

		[Route("tags/series")]
		[HttpPost]
		public Response<TagSeriesContainer> FetchReleaseDates(HttpRequestMessage request, [FromBody] TagsSeriesArguments arguments)
		{
			return Fetch<TagsSeries, TagsSeriesArguments, TagSeriesContainer>(arguments);
		}

	}
}
