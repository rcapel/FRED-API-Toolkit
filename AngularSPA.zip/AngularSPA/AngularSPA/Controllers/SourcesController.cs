﻿using FRED.API.Sources.APIFacades;
using FRED.API.Sources.Arguments;
using FRED.API.Sources.Data;
using System.Net.Http;
using System.Web.Http;

namespace AngularSPA.Controllers
{
	[RoutePrefix("sources")]
	public class SourcesController : FREDController
	{
		[Route("sources")]
		[HttpPost]
		public Response<SourcesContainer> FetchRelease(HttpRequestMessage request, [FromBody] SourcesArguments arguments)
		{
			return Fetch<Sources, SourcesArguments, SourcesContainer>(arguments);
		}

		[Route("source")]
		[HttpPost]
		public Response<SourceContainer> FetchReleases(HttpRequestMessage request, [FromBody] SourceArguments arguments)
		{
			return Fetch<Source, SourceArguments, SourceContainer>(arguments);
		}

		[Route("source/releases")]
		[HttpPost]
		public Response<SourceReleasesContainer> FetchReleaseDates(HttpRequestMessage request, [FromBody] SourceReleasesArguments arguments)
		{
			return Fetch<SourceReleases, SourceReleasesArguments, SourceReleasesContainer>(arguments);
		}

	}
}
