﻿using FRED.API.Sources.APIFacades;
using FRED.API.Sources.Arguments;
using FRED.API.Sources.Data;
using System.Web.Http;

namespace AngularSPA.Controllers
{
	[RoutePrefix("sources")]
	public class SourcesController : FREDController
	{
		[Route("sources")]
		[HttpGet]
		public Response<SourcesContainer> FetchSources()
		{
			return Fetch<Sources, SourcesArguments, SourcesContainer>(new SourcesArguments());
		}

		[Route("source/id/{sourceId:int}")]
		[HttpGet]
		public Response<SourceContainer> FetchSource(int sourceId)
		{
			return Fetch<Source, SourceArguments, SourceContainer>(new SourceArguments { source_id = sourceId });
		}

		[Route("source/releases/id/{sourceId:int}")]
		[HttpGet]
		public Response<SourceReleasesContainer> FetchSourceReleases(int sourceId)
		{
			return Fetch<SourceReleases, SourceReleasesArguments, SourceReleasesContainer>(new SourceReleasesArguments { source_id = sourceId });
		}

	}
}
