﻿using FRED.API.Releases.APIFacades;
using FRED.API.Releases.Arguments;
using FRED.API.Releases.Data;
using FRED.API.Series.Data;
using FRED.API.Sources.Data;
using FRED.API.Tags.Data;
using System.Web.Http;

namespace AngularSPA.Controllers
{
	[RoutePrefix("releases")]
	public class ReleasesController : FREDController
    {
		[Route("releases")]
		[HttpGet]
		public Response<ReleasesContainer> FetchReleases()
		{
			return Fetch<Releases, ReleasesArguments, ReleasesContainer>(new ReleasesArguments());
		}

		[Route("releases/dates")]
		[HttpGet]
		public Response<ReleasesDateContainer> FetchReleasesDates()
		{
			return Fetch<ReleasesDates, ReleasesDatesArguments, ReleasesDateContainer>(new ReleasesDatesArguments());
		}

		[Route("release/id/{id:int}")]
		[HttpGet]
		public Response<ReleaseContainer> FetchRelease(int id)
		{
			return Fetch<Release, ReleaseArguments, ReleaseContainer>(new ReleaseArguments { release_id = id });
		}

		[Route("release/dates/id/{id:int}")]
		[HttpGet]
		public Response<ReleaseDateContainer> FetchReleaseDates(int id)
		{
			return Fetch<ReleaseDates, ReleaseDatesArguments, ReleaseDateContainer>(new ReleaseDatesArguments { release_id = id });
		}

		[Route("release/series/id/{id:int}")]
		[HttpGet]
		public Response<SeriesContainer> FetchReleaseSeries(int id)
		{
			return Fetch<ReleaseSeries, ReleaseSeriesArguments, SeriesContainer>(new ReleaseSeriesArguments { release_id = id });
		}

		[Route("release/sources/id/{id:int}")]
		[HttpGet]
		public Response<SourceContainer> FetchReleaseSources(int id)
		{
			return Fetch<ReleaseSources, ReleaseSourcesArguments, SourceContainer>(new ReleaseSourcesArguments { release_id = id });
		}

		[Route("release/tags/id/{id:int}")]
		[HttpGet]
		public Response<TagContainer> FetchReleaseTags(int id)
		{
			return Fetch<ReleaseTags, ReleaseTagsArguments, TagContainer>(new ReleaseTagsArguments { release_id = id });
		}

		[Route("release/related_tags/id/{id:int}/tag_names/{tagNames}")]
		[HttpGet]
		public Response<TagContainer> FetchReleaseRelatedTags(int id, string tagNames)
		{
			return Fetch<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(new ReleaseRelatedTagsArguments { release_id = id, tag_names = tagNames });
		}

	}
}
