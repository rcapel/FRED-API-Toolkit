﻿using FRED.API.Releases.APIFacades;
using FRED.API.Releases.Arguments;
using FRED.API.Releases.Data;
using FRED.API.Series.Data;
using FRED.API.Sources.Data;
using FRED.API.Tags.Data;
using System.Net.Http;
using System.Web.Http;

namespace AngularSPA.Controllers
{
	[RoutePrefix("releases")]
	public class ReleasesController : FREDController
    {
		[Route("releases")]
		[HttpPost]
		public Response<ReleasesContainer> FetchReleases(HttpRequestMessage request, [FromBody] ReleasesArguments arguments)
		{
			return Fetch<Releases, ReleasesArguments, ReleasesContainer>(arguments);
		}

		[Route("releases/dates")]
		[HttpPost]
		public Response<ReleasesDateContainer> FetchReleasesDates(HttpRequestMessage request, [FromBody] ReleasesDatesArguments arguments)
		{
			return Fetch<ReleasesDates, ReleasesDatesArguments, ReleasesDateContainer>(arguments);
		}

		[Route("release")]
		[HttpPost]
		public Response<ReleaseContainer> FetchRelease(HttpRequestMessage request, [FromBody] ReleaseArguments arguments)
		{
			return Fetch<Release, ReleaseArguments, ReleaseContainer>(arguments);
		}

		[Route("release/dates")]
		[HttpPost]
		public Response<ReleaseDateContainer> FetchReleaseDates(HttpRequestMessage request, [FromBody] ReleaseDatesArguments arguments)
		{
			return Fetch<ReleaseDates, ReleaseDatesArguments, ReleaseDateContainer>(arguments);
		}

		[Route("release/series")]
		[HttpPost]
		public Response<SeriesContainer> FetchReleaseSeries(HttpRequestMessage request, [FromBody] ReleaseSeriesArguments arguments)
		{
			return Fetch<ReleaseSeries, ReleaseSeriesArguments, SeriesContainer>(arguments);
		}

		[Route("release/sources")]
		[HttpPost]
		public Response<SourceContainer> FetchReleaseSources(HttpRequestMessage request, [FromBody] ReleaseSourcesArguments arguments)
		{
			return Fetch<ReleaseSources, ReleaseSourcesArguments, SourceContainer>(arguments);
		}

		[Route("release/tags")]
		[HttpPost]
		public Response<TagContainer> FetchReleaseTags(HttpRequestMessage request, [FromBody] ReleaseTagsArguments arguments)
		{
			return Fetch<ReleaseTags, ReleaseTagsArguments, TagContainer>(arguments);
		}

		[Route("release/related_tags")]
		[HttpPost]
		public Response<TagContainer> FetchReleaseRelatedTags(HttpRequestMessage request, [FromBody] ReleaseRelatedTagsArguments arguments)
		{
			return Fetch<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(arguments);
		}

	}
}
