﻿using FRED.API.Categories.APIFacades;
using FRED.API.Categories.Arguments;
using FRED.API.Categories.Data;
using FRED.API.Series.Data;
using FRED.API.Tags.Data;
using System.Net.Http;
using System.Web.Http;

namespace AngularSPA.Controllers
{
	[RoutePrefix("categories")]
	public class CategoriesController : FREDController
    {
		[Route("category")]
		[HttpPost]
		public Response<CategoryContainer> FetchCategory(HttpRequestMessage request, [FromBody] CategoryArguments arguments)
		{
			return Fetch<Category, CategoryArguments, CategoryContainer>(arguments);
		}

		[Route("category/children")]
		[HttpPost]
		public Response<CategoryContainer> FetchCategoryChildren(HttpRequestMessage request, [FromBody] CategoryChildrenArguments arguments)
		{
			return Fetch<CategoryChildren, CategoryChildrenArguments, CategoryContainer>(arguments);
		}

		[Route("category/related")]
		[HttpPost]
		public Response<CategoryContainer> FetchCategoryRelated(HttpRequestMessage request, [FromBody] CategoryRelatedArguments arguments)
		{
			return Fetch<CategoryRelated, CategoryRelatedArguments, CategoryContainer>(arguments);
		}

		[Route("category/series")]
		[HttpPost]
		public Response<SeriesContainer> FetchCategorySeries(HttpRequestMessage request, [FromBody] CategorySeriesArguments arguments)
		{
			return Fetch<CategorySeries, CategorySeriesArguments, SeriesContainer>(arguments);
		}

		[Route("category/tags")]
		[HttpPost]
		public Response<TagContainer> FetchCategoryTags(HttpRequestMessage request, [FromBody] CategoryTagsArguments arguments)
		{
			return Fetch<CategoryTags, CategoryTagsArguments, TagContainer>(arguments);
		}

		[Route("category/related_tags")]
		[HttpPost]
		public Response<TagContainer> FetchCategoryRelatedTags(HttpRequestMessage request, [FromBody] CategoryRelatedTagsArguments arguments)
		{
			return Fetch<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(arguments);
		}

	}
}
