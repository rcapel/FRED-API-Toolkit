﻿using FRED.API.Categories.APIFacades;
using FRED.API.Categories.Arguments;
using FRED.API.Categories.Data;
using FRED.API.Series.Data;
using FRED.API.Tags.Data;
using System.Web.Http;

namespace AngularSPA.Controllers
{
	[RoutePrefix("categories")]
	public class CategoriesController : FREDController
    {
		[Route("category/id/{id:int}")]
		[HttpGet]
		public Response<CategoryContainer> FetchCategory(int id)
		{
			return Fetch<Category, CategoryArguments, CategoryContainer>(new CategoryArguments { category_id = id });
		}

		[Route("category/children/id/{id:int}")]
		[HttpGet]
		public Response<CategoryContainer> FetchCategoryChildren(int id)
		{
			return Fetch<CategoryChildren, CategoryChildrenArguments, CategoryContainer>(new CategoryChildrenArguments { category_id = id });
		}

		[Route("category/related/id/{id:int}")]
		[HttpGet]
		public Response<CategoryContainer> FetchCategoryRelated(int id)
		{
			return Fetch<CategoryRelated, CategoryRelatedArguments, CategoryContainer>(new CategoryRelatedArguments { category_id = id });
		}

		[Route("category/series/id/{id:int}")]
		[HttpGet]
		public Response<SeriesContainer> FetchCategorySeries(int id)
		{
			return Fetch<CategorySeries, CategorySeriesArguments, SeriesContainer>(new CategorySeriesArguments { category_id = id });
		}

		[Route("category/tags/id/{id:int}")]
		[HttpGet]
		public Response<TagContainer> FetchCategoryTags(int id)
		{
			return Fetch<CategoryTags, CategoryTagsArguments, TagContainer>(new CategoryTagsArguments { category_id = id });
		}

		[Route("category/related_tags/id/{id:int}/tag_names/{tagNames}")]
		[HttpGet]
		public Response<TagContainer> FetchCategoryRelatedTags(int id, string tagNames)
		{
			return Fetch<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(new CategoryRelatedTagsArguments { category_id = id, tag_names = tagNames });
		}

	}
}
