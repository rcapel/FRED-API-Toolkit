﻿using FRED.API.Categories.Data;
using FRED.API.Releases.Data;
using FRED.API.Series.APIFacades;
using FRED.API.Series.Arguments;
using FRED.API.Series.Data;
using FRED.API.Tags.Data;
using System.Net.Http;
using System.Web.Http;

namespace AngularSPA.Controllers
{
	[RoutePrefix("series")]
	public class SeriesController : FREDController
	{
		[Route("series")]
		[HttpPost]
		public Response<SingleSeriesContainer> FetchSeries(HttpRequestMessage request, [FromBody] SeriesArguments arguments)
		{
			return Fetch<Series, SeriesArguments, SingleSeriesContainer>(arguments);
		}

		[Route("series/categories")]
		[HttpPost]
		public Response<CategoryContainer> FetchSeriesCategories(HttpRequestMessage request, [FromBody] SeriesCategoriesArguments arguments)
		{
			return Fetch<SeriesCategories, SeriesCategoriesArguments, CategoryContainer>(arguments);
		}

		[Route("series/observations")]
		[HttpPost]
		public Response<ObservationContainer> FetchSeriesObservations(HttpRequestMessage request, [FromBody] SeriesObservationsArguments arguments)
		{
			return Fetch<SeriesObservations, SeriesObservationsArguments, ObservationContainer>(arguments);
		}

		[Route("series/release")]
		[HttpPost]
		public Response<ReleaseContainer> FetchSeriesRelease(HttpRequestMessage request, [FromBody] SeriesReleaseArguments arguments)
		{
			return Fetch<SeriesRelease, SeriesReleaseArguments, ReleaseContainer>(arguments);
		}

		[Route("series/search")]
		[HttpPost]
		public Response<SeriesSearchContainer> FetchSeriesSearch(HttpRequestMessage request, [FromBody] SeriesSearchArguments arguments)
		{
			return Fetch<SeriesSearch, SeriesSearchArguments, SeriesSearchContainer>(arguments);
		}

		[Route("series/search/tags")]
		[HttpPost]
		public Response<TagContainer> FetchSeriesSearchTags(HttpRequestMessage request, [FromBody] SeriesSearchTagsArguments arguments)
		{
			return Fetch<SeriesSearchTags, SeriesSearchTagsArguments, TagContainer>(arguments);
		}

		[Route("series/search/related_tags")]
		[HttpPost]
		public Response<TagContainer> FetchSeriesSearchRelatedTags(HttpRequestMessage request, [FromBody] SeriesSearchRelatedTagsArguments arguments)
		{
			return Fetch<SeriesSearchRelatedTags, SeriesSearchRelatedTagsArguments, TagContainer>(arguments);
		}

		[Route("series/tags")]
		[HttpPost]
		public Response<TagContainer> FetchSeriesTags(HttpRequestMessage request, [FromBody] SeriesTagsArguments arguments)
		{
			return Fetch<SeriesTags, SeriesTagsArguments, TagContainer>(arguments);
		}

		[Route("series/updates")]
		[HttpPost]
		public Response<SeriesUpdateContainer> FetchSeriesUpdates(HttpRequestMessage request, [FromBody] SeriesUpdatesArguments arguments)
		{
			return Fetch<SeriesUpdates, SeriesUpdatesArguments, SeriesUpdateContainer>(arguments);
		}

		[Route("series/vintagedates")]
		[HttpPost]
		public Response<VintageDateContainer> FetchSeriesVintageDates(HttpRequestMessage request, [FromBody] SeriesVintageDatesArguments arguments)
		{
			return Fetch<SeriesVintageDates, SeriesVintageDatesArguments, VintageDateContainer>(arguments);
		}

	}
}
