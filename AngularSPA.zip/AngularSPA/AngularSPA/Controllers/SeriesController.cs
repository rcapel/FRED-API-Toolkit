﻿using FRED.API.Categories.Data;
using FRED.API.Releases.Data;
using FRED.API.Series.APIFacades;
using FRED.API.Series.Arguments;
using FRED.API.Series.Data;
using FRED.API.Tags.Data;
using System.Web.Http;

namespace AngularSPA.Controllers
{
	[RoutePrefix("series")]
	public class SeriesController : FREDController
	{
		[Route("series/id/{id}")]
		[HttpGet]
		public Response<SingleSeriesContainer> FetchSeries(string id)
		{
			return Fetch<Series, SeriesArguments, SingleSeriesContainer>(new SeriesArguments { series_id = id });
		}

		[Route("series/categories/id/{id}")]
		[HttpGet]
		public Response<CategoryContainer> FetchSeriesCategories(string id)
		{
			return Fetch<SeriesCategories, SeriesCategoriesArguments, CategoryContainer>(new SeriesCategoriesArguments { series_id = id });
		}

		[Route("series/observations/id/{id}")]
		[HttpGet]
		public Response<ObservationContainer> FetchSeriesObservations(string id)
		{
			return Fetch<SeriesObservations, SeriesObservationsArguments, ObservationContainer>(new SeriesObservationsArguments { series_id = id });
		}

		[Route("series/release/id/{id}")]
		[HttpGet]
		public Response<ReleaseContainer> FetchSeriesRelease(string id)
		{
			return Fetch<SeriesRelease, SeriesReleaseArguments, ReleaseContainer>(new SeriesReleaseArguments { series_id = id });
		}

		[Route("series/search/search_text/{searchText}")]
		[HttpGet]
		public Response<SeriesSearchContainer> FetchSeriesSearch(string searchText)
		{
			return Fetch<SeriesSearch, SeriesSearchArguments, SeriesSearchContainer>(new SeriesSearchArguments { search_text = searchText });
		}

		[Route("series/search/tags/series_search_text/{seriesSearchText}")]
		[HttpGet]
		public Response<TagContainer> FetchSeriesSearchTags(string seriesSearchText)
		{
			return Fetch<SeriesSearchTags, SeriesSearchTagsArguments, TagContainer>(new SeriesSearchTagsArguments { series_search_text = seriesSearchText });
		}

		[Route("series/search/related_tags/series_search_text/{seriesSearchText}/tag_names/{tagNames}")]
		[HttpGet]
		public Response<TagContainer> FetchSeriesSearchRelatedTags(string seriesSearchText, string tagNames)
		{
			return Fetch<SeriesSearchRelatedTags, SeriesSearchRelatedTagsArguments, TagContainer>(
				new SeriesSearchRelatedTagsArguments { series_search_text = seriesSearchText, tag_names = tagNames });
		}

		[Route("series/tags/id/{id}")]
		[HttpGet]
		public Response<TagContainer> FetchSeriesTags(string id)
		{
			return Fetch<SeriesTags, SeriesTagsArguments, TagContainer>(new SeriesTagsArguments { series_id = id });
		}

		[Route("series/updates")]
		[HttpGet]
		public Response<SeriesUpdateContainer> FetchSeriesUpdates()
		{
			return Fetch<SeriesUpdates, SeriesUpdatesArguments, SeriesUpdateContainer>(new SeriesUpdatesArguments());
		}

		[Route("series/vintagedates/id/{id}")]
		[HttpGet]
		public Response<VintageDateContainer> FetchSeriesVintageDates(string id)
		{
			return Fetch<SeriesVintageDates, SeriesVintageDatesArguments, VintageDateContainer>(new SeriesVintageDatesArguments { series_id = id });
		}

	}
}
