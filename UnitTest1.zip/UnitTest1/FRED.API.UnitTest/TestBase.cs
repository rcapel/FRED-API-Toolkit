﻿using FRED.API.Base.APIFacades;
using FRED.API.Base.Arguments;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace FRED.API.UnitTest
{
	public abstract class TestBase
	{
		#region properties

		protected static string ApiKey
		{
			get { return "2bb51ce5cf297e0a999c232d8b6238e5"; }
		}

		protected static int ValidMinimumLimit
		{
			get { return 1; }
		}

		protected static int InvalidMinimumLimit
		{
			get { return 0; }
		}

		protected static int ValidMaximumLimit
		{
			get { return 1000; }
		}

		protected static int InvalidMaximumLimit
		{
			get { return 1001; }
		}

		protected static int InvalidOffset
		{
			get { return -1; }
		}

		#endregion

		#region protected methods

		protected void Test<TApi, TArguments, TContainer>(Action<TArguments> setArguments, Action<TApi> apiCallback, bool clearValidators = false)
			where TApi : ApiBase<TArguments, TContainer>, new()
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			TApi api = new TApi() { ApiKey = ApiKey };
			setArguments(api.Arguments);
			if (clearValidators)
			{
				api.Arguments.Validators.Clear();
			}
			TContainer container = api.Fetch();
			apiCallback(api);
		}

		protected void AssertSuccess_ToolkitValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api, TContainer container)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			Assert.IsNotNull(container);
			AssertSuccess_ToolkitValidation(api);
		}

		protected void AssertFailure_ToolkitValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api, TContainer container)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			Assert.IsNull(container);
			AssertFailure_ToolkitValidation(api);
		}

		protected void AssertSuccess_FREDValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api, TContainer container)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			Assert.IsNotNull(container);
			AssertSuccess_FREDValidation(api);
		}

		protected void AssertFailure_FREDValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api, TContainer container)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			Assert.IsNull(container);
			AssertFailure_FREDValidation(api);
		}

		protected void AssertInvalidReleaseId_ToolkitValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			AssertFailure_ToolkitValidation(api);
			Assert.IsTrue(api.Arguments.ValidationErrors.ContainsKey("release_id") &&
				api.Arguments.ValidationErrors["release_id"].StartsWith("Property 'release_id' must be valued and positive"));
			Assert.IsTrue(api.Arguments.ValidationErrors.Count == 1);
		}

		protected void AssertInvalidSeriesId_ToolkitValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			AssertFailure_ToolkitValidation(api);
			Assert.IsTrue(api.Arguments.ValidationErrors.ContainsKey("series_id") &&
				api.Arguments.ValidationErrors["series_id"].StartsWith("Property 'series_id' must be valued."));
			Assert.IsTrue(api.Arguments.ValidationErrors.Count == 1);
		}

		protected void AssertInvalidSourceId_ToolkitValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			AssertFailure_ToolkitValidation(api);
			Assert.IsTrue(api.Arguments.ValidationErrors.ContainsKey("source_id") &&
				api.Arguments.ValidationErrors["source_id"].StartsWith("Property 'source_id' must be valued and positive"));
			Assert.IsTrue(api.Arguments.ValidationErrors.Count == 1);
		}

		protected void AssertInvalidTagNames_ToolkitValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			AssertFailure_ToolkitValidation(api);
			Assert.IsTrue(api.Arguments.ValidationErrors.ContainsKey("tag_names") &&
				api.Arguments.ValidationErrors["tag_names"].StartsWith("Property 'tag_names' must be valued"));
			Assert.IsTrue(api.Arguments.ValidationErrors.Count == 1);
		}

		protected void AssertInvalidSearchText_ToolkitValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			AssertFailure_ToolkitValidation(api);
			Assert.IsTrue(api.Arguments.ValidationErrors.ContainsKey("search_text") &&
				api.Arguments.ValidationErrors["search_text"].StartsWith("Property 'search_text' must be valued"));
			Assert.IsTrue(api.Arguments.ValidationErrors.Count == 1);
		}

		protected void AssertInvalidSeriesSearchText_ToolkitValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			AssertFailure_ToolkitValidation(api);
			Assert.IsTrue(api.Arguments.ValidationErrors.ContainsKey("series_search_text") &&
				api.Arguments.ValidationErrors["series_search_text"].StartsWith("Property 'series_search_text' must be valued"));
			Assert.IsTrue(api.Arguments.ValidationErrors.Count == 1);
		}

		protected void AssertInvalidLimit_ToolkitValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			AssertFailure_ToolkitValidation(api);
			Assert.IsTrue(api.Arguments.ValidationErrors.ContainsKey("limit") &&
				api.Arguments.ValidationErrors["limit"].StartsWith("Property 'limit' must be between 1 and 1000"));
			Assert.IsTrue(api.Arguments.ValidationErrors.Count == 1);
		}

		protected void AssertInvalidOffset_ToolkitValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			AssertFailure_ToolkitValidation(api);
			Assert.IsTrue(api.Arguments.ValidationErrors.ContainsKey("offset"));
			Assert.IsTrue(api.Arguments.ValidationErrors.Count == 1);
		}

		protected void AssertInvalidTagNamesAndExcludedTagNames_ToolkitValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			AssertFailure_ToolkitValidation(api);
			Assert.IsTrue(api.Arguments.ValidationErrors.ContainsKey("tag_names/exclude_tag_names"));
			Assert.IsTrue(api.Arguments.ValidationErrors.Count > 0);
		}

		protected void AssertInvalidReleaseId_FREDValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			AssertFailure_FREDValidation(api);
			Assert.IsTrue(api.FetchMessage.StartsWith("Bad Request.  Variable release_id is not a positive integer."));
		}

		protected void AssertInvalidSeriesId_FREDValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			AssertFailure_FREDValidation(api);
			Assert.IsTrue(api.FetchMessage.StartsWith("Bad Request.  Variable series_id has not been set."));
		}

		protected void AssertInvalidSourceId_FREDValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			AssertFailure_FREDValidation(api);
			Assert.IsTrue(api.FetchMessage.StartsWith("Bad Request.  Variable source_id is not a positive integer."));
		}

		protected void AssertInvalidTagNames_FREDValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			AssertFailure_FREDValidation(api);
			Assert.IsTrue(api.FetchMessage.StartsWith("Bad Request.  The variable tag_names must be set."));
		}

		protected void AssertInvalidSearchText_FREDValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			AssertFailure_FREDValidation(api);
			Assert.IsTrue(api.FetchMessage.StartsWith("Bad Request.  Variable search_text is not set."));
		}

		protected void AssertInvalidSeriesSearchText_FREDValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			AssertFailure_FREDValidation(api);
			Assert.IsTrue(api.FetchMessage.StartsWith("Bad Request.  Variable series_search_text is not set."));
		}

		protected void AssertInvalidLimit1000_FREDValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			AssertFailure_FREDValidation(api);
			Assert.IsTrue(api.FetchMessage.StartsWith("Bad Request.  Variable limit is not between 1 and 1000."));
		}

		protected void AssertInvalidLimit10000_FREDValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			AssertFailure_FREDValidation(api);
			Assert.IsTrue(api.FetchMessage.StartsWith("Bad Request.  Variable limit is not between 1 and 10000."));
		}

		protected void AssertInvalidLimit100000_FREDValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			AssertFailure_FREDValidation(api);
			Assert.IsTrue(api.FetchMessage.StartsWith("Bad Request.  Variable limit is not between 1 and 100000."));
		}

		protected void AssertInvalidOffset_FREDValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			AssertFailure_FREDValidation(api);
			Assert.IsTrue(api.FetchMessage.StartsWith("Bad Request.  Variable offset is not 0 or a positive integer."));
		}

		protected void AssertInvalidTagNamesAndExcludedTagNames_FREDValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			AssertFailure_FREDValidation(api);
			Assert.IsTrue(api.FetchMessage.StartsWith("Bad Request.  Variable exclude_tag_names requires that variable tag_names also be set") ||
							api.FetchMessage.StartsWith("Bad Request.  The variable tag_names must be set."));
		}

		#endregion

		#region private methods

		protected void AssertSuccess_ToolkitValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			Assert.IsNull(api.Exception);
			Assert.IsNull(api.FetchMessage);
			Assert.IsNotNull(api.URL);
			Assert.IsTrue(api.Arguments.Validators.Count > 0);
			Assert.IsNull(api.Arguments.ValidationErrors);
		}

		protected void AssertFailure_ToolkitValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			Assert.IsNull(api.Exception);
			Assert.IsNull(api.FetchMessage);
			Assert.IsNull(api.URL);
			Assert.IsTrue(api.Arguments.Validators.Count > 0);
			Assert.IsNotNull(api.Arguments.ValidationErrors);
		}

		protected void AssertSuccess_FREDValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			Assert.IsNull(api.Exception);
			Assert.IsNull(api.FetchMessage);
			Assert.IsNotNull(api.URL);
			Assert.IsTrue(api.Arguments.Validators.Count == 0);
			Assert.IsNull(api.Arguments.ValidationErrors);
		}

		protected void AssertFailure_FREDValidation<TArguments, TContainer>(ApiBase<TArguments, TContainer> api)
			where TArguments : ArgumentsBase, new()
			where TContainer : class
		{
			Assert.IsNull(api.Exception);
			Assert.IsNotNull(api.FetchMessage);
			Assert.IsNotNull(api.URL);
			Assert.IsTrue(api.Arguments.Validators.Count == 0);
			Assert.IsNull(api.Arguments.ValidationErrors);
		}

		#endregion

	}
}
