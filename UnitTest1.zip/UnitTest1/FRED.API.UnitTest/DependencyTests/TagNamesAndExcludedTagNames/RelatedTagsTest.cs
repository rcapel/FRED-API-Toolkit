﻿using FRED.API.Tags.APIFacades;
using FRED.API.Tags.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.TagNamesAndExcludedTagNames
{
	[TestClass]
	public class RelatedTagsTest : TestBase
	{
		[TestMethod]
		public void RelatedTags_InvalidTagNamesAndExcludedTagNames_ToolkitValidation()
		{
			Test<RelatedTags, RelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.exclude_tag_names = "quarterly";
			},
			AssertInvalidTagNamesAndExcludedTagNames_ToolkitValidation);
		}

		[TestMethod]
		public void RelatedTags_ValidTagNamesAndExcludedTagNames_ToolkitValidation()
		{
			Test<RelatedTags, RelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services";
				arguments.exclude_tag_names = "quarterly";
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void RelatedTags_InvalidTagNamesAndExcludedTagNames_FREDValidation()
		{
			Test<RelatedTags, RelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.exclude_tag_names = "quarterly";
			},
			AssertInvalidTagNamesAndExcludedTagNames_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void RelatedTags_ValidTagNamesAndExcludedTagNames_FREDValidation()
		{
			Test<RelatedTags, RelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services";
				arguments.exclude_tag_names = "quarterly";
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
