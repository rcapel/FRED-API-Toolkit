﻿using FRED.API.Tags.APIFacades;
using FRED.API.Tags.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.TagNamesAndExcludedTagNames
{
	[TestClass]
	public class TagsSeriesTest : TestBase
	{
		[TestMethod]
		public void TagsSeries_InvalidTagNamesAndExcludedTagNames_ToolkitValidation()
		{
			Test<TagsSeries, TagsSeriesArguments, TagSeriesContainer>(
			(arguments) =>
			{
				arguments.exclude_tag_names = "quarterly";
			},
			AssertInvalidTagNamesAndExcludedTagNames_ToolkitValidation);
		}

		[TestMethod]
		public void TagsSeries_ValidTagNamesAndExcludedTagNames_ToolkitValidation()
		{
			Test<TagsSeries, TagsSeriesArguments, TagSeriesContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services";
				arguments.exclude_tag_names = "quarterly";
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void TagsSeries_InvalidTagNamesAndExcludedTagNames_FREDValidation()
		{
			Test<TagsSeries, TagsSeriesArguments, TagSeriesContainer>(
			(arguments) =>
			{
				arguments.exclude_tag_names = "quarterly";
			},
			AssertInvalidTagNamesAndExcludedTagNames_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void TagsSeries_ValidTagNamesAndExcludedTagNames_FREDValidation()
		{
			Test<TagsSeries, TagsSeriesArguments, TagSeriesContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services";
				arguments.exclude_tag_names = "quarterly";
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
