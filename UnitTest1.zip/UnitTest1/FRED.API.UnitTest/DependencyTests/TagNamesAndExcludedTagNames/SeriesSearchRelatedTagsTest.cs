﻿using FRED.API.Series.APIFacades;
using FRED.API.Series.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.TagNamesAndExcludedTagNames
{
	[TestClass]
	public class SeriesSearchRelatedTagsTest : TestBase
	{
		[TestMethod]
		public void aSeriesSearchRelatedTags_InvalidTagNamesAndExcludedTagNames_ToolkitValidation()
		{
			Test<SeriesSearchRelatedTags, SeriesSearchRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.exclude_tag_names = "quarterly";
			},
			AssertInvalidTagNamesAndExcludedTagNames_ToolkitValidation);
		}

		[TestMethod]
		public void aSeriesSearchRelatedTags_ValidTagNamesAndExcludedTagNames_ToolkitValidation()
		{
			Test<SeriesSearchRelatedTags, SeriesSearchRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_search_text = "mortgage+rate";
				arguments.tag_names = "quarterly";
				arguments.exclude_tag_names = "quarterly";
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearchRelatedTags_InvalidTagNamesAndExcludedTagNames_FREDValidation()
		{
			Test<SeriesSearchRelatedTags, SeriesSearchRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.exclude_tag_names = "quarterly";
			},
			AssertInvalidTagNamesAndExcludedTagNames_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesSearchRelatedTags_ValidTagNamesAndExcludedTagNames_FREDValidation()
		{
			Test<SeriesSearchRelatedTags, SeriesSearchRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_search_text = "mortgage+rate";
				arguments.tag_names = "quarterly";
				arguments.exclude_tag_names = "quarterly";
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
