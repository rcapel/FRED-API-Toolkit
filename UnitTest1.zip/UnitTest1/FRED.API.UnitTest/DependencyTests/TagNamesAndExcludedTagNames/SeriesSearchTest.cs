﻿using FRED.API.Series.APIFacades;
using FRED.API.Series.Arguments;
using FRED.API.Series.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.TagNamesAndExcludedTagNames
{
	[TestClass]
	public class SeriesSearchTest : TestBase
	{
		[TestMethod]
		public void SeriesSearch_InvalidTagNamesAndExcludedTagNames_ToolkitValidation()
		{
			Test<SeriesSearch, SeriesSearchArguments, SeriesSearchContainer>(
			(arguments) =>
			{
				arguments.search_text = "monetary+service+index";
				arguments.exclude_tag_names = "quarterly";
			},
			AssertInvalidTagNamesAndExcludedTagNames_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearch_ValidTagNamesAndExcludedTagNames_ToolkitValidation()
		{
			Test<SeriesSearch, SeriesSearchArguments, SeriesSearchContainer>(
			(arguments) =>
			{
				arguments.search_text = "monetary+service+index";
				arguments.tag_names = "quarterly";
				arguments.exclude_tag_names = "quarterly";
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearch_InvalidTagNamesAndExcludedTagNames_FREDValidation()
		{
			Test<SeriesSearch, SeriesSearchArguments, SeriesSearchContainer>(
			(arguments) =>
			{
				arguments.search_text = "monetary+service+index";
				arguments.exclude_tag_names = "quarterly";
			},
			AssertInvalidTagNamesAndExcludedTagNames_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesSearch_ValidTagNamesAndExcludedTagNames_FREDValidation()
		{
			Test<SeriesSearch, SeriesSearchArguments, SeriesSearchContainer>(
			(arguments) =>
			{
				arguments.search_text = "monetary+service+index";
				arguments.tag_names = "quarterly";
				arguments.exclude_tag_names = "quarterly";
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
