﻿using FRED.API.Categories.APIFacades;
using FRED.API.Categories.Arguments;
using FRED.API.Series.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.TagNamesAndExcludedTagNames
{
	[TestClass]
	public class CategorySeriesTagNamesAndExcludedTagNamesTest : TestBase
	{
		[TestMethod]
		public void CategorySeries_InvalidTagNamesAndExcludedTagNames_ToolkitValidation()
		{
			Test<CategorySeries, CategorySeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.exclude_tag_names = "quarterly";
			},
			AssertInvalidTagNamesAndExcludedTagNames_ToolkitValidation);
		}

		[TestMethod]
		public void CategorySeries_ValidTagNamesAndExcludedTagNames_ToolkitValidation()
		{
			Test<CategorySeries, CategorySeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services";
				arguments.exclude_tag_names = "quarterly";
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void CategorySeries_InvalidTagNamesAndExcludedTagNames_FREDValidation()
		{
			Test<CategorySeries, CategorySeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.exclude_tag_names = "quarterly";
			},
			AssertInvalidTagNamesAndExcludedTagNames_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void CategorySeries_ValidTagNamesAndExcludedTagNames_FREDValidation()
		{
			Test<CategorySeries, CategorySeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services";
				arguments.exclude_tag_names = "quarterly";
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
