﻿using FRED.API.Releases.APIFacades;
using FRED.API.Releases.Arguments;
using FRED.API.Releases.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Offset
{
	[TestClass]
	public class ReleaseDatesTest : TestBase
	{
		[TestMethod]
		public void ReleaseDates_InvalidOffset_ToolkitValidation()
		{
			Test<ReleaseDates, ReleaseDatesArguments, ReleaseDateContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseDates_ValidOffset_ToolkitValidation()
		{
			Test<ReleaseDates, ReleaseDatesArguments, ReleaseDateContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.offset = 0;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseDates_InvalidOffset_FREDValidation()
		{
			Test<ReleaseDates, ReleaseDatesArguments, ReleaseDateContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleaseDates_ValidOffset_FREDValidation()
		{
			Test<ReleaseDates, ReleaseDatesArguments, ReleaseDateContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.offset = 0;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
