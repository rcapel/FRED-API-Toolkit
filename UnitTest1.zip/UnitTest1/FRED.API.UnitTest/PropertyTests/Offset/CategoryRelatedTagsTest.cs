﻿using FRED.API.Categories.APIFacades;
using FRED.API.Categories.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Offset
{
	[TestClass]
	public class CategoryRelatedTagsTest : TestBase
	{
		[TestMethod]
		public void CategoryRelatedTags_InvalidOffset_ToolkitValidation()
		{
			Test<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services;quarterly";
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_ToolkitValidation);
		}

		[TestMethod]
		public void CategoryRelatedTags_ValidOffset_ToolkitValidation()
		{
			Test<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services;quarterly";
				arguments.offset = 0;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void CategoryRelatedTags_InvalidOffset_FREDValidation()
		{
			Test<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services;quarterly";
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void CategoryRelatedTags_ValidOffset_FREDValidation()
		{
			Test<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services;quarterly";
				arguments.offset = 0;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
