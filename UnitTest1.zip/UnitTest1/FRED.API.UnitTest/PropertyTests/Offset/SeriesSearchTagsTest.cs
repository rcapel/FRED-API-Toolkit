﻿using FRED.API.Series.APIFacades;
using FRED.API.Series.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Offset
{
	[TestClass]
	public class SeriesSearchTagsTagsTest : TestBase
	{
		[TestMethod]
		public void SeriesSearchTags_InvalidOffset_ToolkitValidation()
		{
			Test<SeriesSearchTags, SeriesSearchTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_search_text = "monetary+service+index";
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearchTags_ValidOffset_ToolkitValidation()
		{
			Test<SeriesSearchTags, SeriesSearchTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_search_text = "monetary+service+index";
				arguments.offset = 0;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearchTags_InvalidOffset_FREDValidation()
		{
			Test<SeriesSearchTags, SeriesSearchTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_search_text = "monetary+service+index";
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesSearchTags_ValidOffset_FREDValidation()
		{
			Test<SeriesSearchTags, SeriesSearchTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_search_text = "monetary+service+index";
				arguments.offset = 0;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
