﻿using FRED.API.Releases.APIFacades;
using FRED.API.Releases.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Offset
{
	[TestClass]
	public class ReleaseTagsTest : TestBase
	{
		[TestMethod]
		public void ReleaseTags_InvalidOffset_ToolkitValidation()
		{
			Test<ReleaseTags, ReleaseTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.offset = InvalidOffset;
            },
			AssertInvalidOffset_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseTags_ValidOffset_ToolkitValidation()
		{
			Test<ReleaseTags, ReleaseTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.offset = 0;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseTags_InvalidOffset_FREDValidation()
		{
			Test<ReleaseTags, ReleaseTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleaseTags_ValidOffset_FREDValidation()
		{
			Test<ReleaseTags, ReleaseTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.offset = 0;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
