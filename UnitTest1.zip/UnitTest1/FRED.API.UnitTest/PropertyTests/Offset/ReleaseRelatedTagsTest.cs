﻿using FRED.API.Releases.APIFacades;
using FRED.API.Releases.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Offset
{
	[TestClass]
	public class ReleaseRelatedTagsTest : TestBase
	{
		[TestMethod]
		public void ReleaseRelatedTags_InvalidOffset_ToolkitValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.tag_names = "sa;foreign";
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseRelatedTags_ValidOffset_ToolkitValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.tag_names = "sa;foreign";
				arguments.offset = 0;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseRelatedTags_InvalidOffset_FREDValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.tag_names = "sa;foreign";
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleaseRelatedTags_ValidOffset_FREDValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.tag_names = "sa;foreign";
				arguments.offset = 0;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
