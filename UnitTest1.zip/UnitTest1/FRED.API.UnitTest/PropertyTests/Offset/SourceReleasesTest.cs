﻿using FRED.API.Sources.APIFacades;
using FRED.API.Sources.Arguments;
using FRED.API.Sources.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Offset
{
	[TestClass]
	public class SourceReleasesTest : TestBase
	{
		[TestMethod]
		public void SourceReleases_InvalidOffset_ToolkitValidation()
		{
			Test<SourceReleases, SourceReleasesArguments, SourceReleasesContainer>(
			(arguments) =>
			{
				arguments.source_id = 1;
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_ToolkitValidation);
		}

		[TestMethod]
		public void SourceReleases_ValidOffset_ToolkitValidation()
		{
			Test<SourceReleases, SourceReleasesArguments, SourceReleasesContainer>(
			(arguments) =>
			{
				arguments.source_id = 1;
				arguments.offset = 0;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void SourceReleases_InvalidOffset_FREDValidation()
		{
			Test<SourceReleases, SourceReleasesArguments, SourceReleasesContainer>(
			(arguments) =>
			{
				arguments.source_id = 1;
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SourceReleases_ValidOffset_FREDValidation()
		{
			Test<SourceReleases, SourceReleasesArguments, SourceReleasesContainer>(
			(arguments) =>
			{
				arguments.source_id = 1;
				arguments.offset = 0;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
