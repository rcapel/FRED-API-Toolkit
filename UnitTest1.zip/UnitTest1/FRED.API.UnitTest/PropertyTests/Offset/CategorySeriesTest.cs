﻿using FRED.API.Categories.APIFacades;
using FRED.API.Categories.Arguments;
using FRED.API.Series.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Offset
{
	[TestClass]
	public class CategorySeriesTest : TestBase
	{
		[TestMethod]
		public void CategorySeries_InvalidOffset_ToolkitValidation()
		{
			Test<CategorySeries, CategorySeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_ToolkitValidation);
		}

		[TestMethod]
		public void CategorySeries_ValidOffset_ToolkitValidation()
		{
			Test<CategorySeries, CategorySeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.offset = 0;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void CategorySeries_InvalidOffset_FREDValidation()
		{
			Test<CategorySeries, CategorySeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void CategorySeries_ValidOffset_FREDValidation()
		{
			Test<CategorySeries, CategorySeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.offset = 0;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
