﻿using FRED.API.Tags.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Offset
{
	[TestClass]
	public class TagsTest : TestBase
	{
		[TestMethod]
		public void Tags_InvalidOffset_ToolkitValidation()
		{
			Test<Tags.APIFacades.Tags, TagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_ToolkitValidation);
		}

		[TestMethod]
		public void Tags_ValidOffset_ToolkitValidation()
		{
			Test<Tags.APIFacades.Tags, TagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.offset = 0;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void Tags_InvalidOffset_FREDValidation()
		{
			Test<Tags.APIFacades.Tags, TagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void Tags_ValidOffset_FREDValidation()
		{
			Test<Tags.APIFacades.Tags, TagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.offset = 0;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
