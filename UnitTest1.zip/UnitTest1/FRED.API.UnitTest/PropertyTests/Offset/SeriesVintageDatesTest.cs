﻿using FRED.API.Series.APIFacades;
using FRED.API.Series.Arguments;
using FRED.API.Series.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Offset
{
	[TestClass]
	public class SeriesVintageDatesTest : TestBase
	{
		[TestMethod]
		public void SeriesVintageDates_InvalidOffset_ToolkitValidation()
		{
			Test<SeriesVintageDates, SeriesVintageDatesArguments, VintageDateContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesVintageDates_ValidOffset_ToolkitValidation()
		{
			Test<SeriesVintageDates, SeriesVintageDatesArguments, VintageDateContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.offset = 0;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesVintageDates_InvalidOffset_FREDValidation()
		{
			Test<SeriesVintageDates, SeriesVintageDatesArguments, VintageDateContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesVintageDates_ValidOffset_FREDValidation()
		{
			Test<SeriesVintageDates, SeriesVintageDatesArguments, VintageDateContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.offset = 0;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
