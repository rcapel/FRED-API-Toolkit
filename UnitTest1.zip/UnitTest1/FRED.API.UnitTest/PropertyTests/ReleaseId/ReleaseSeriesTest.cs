﻿using FRED.API.Releases.APIFacades;
using FRED.API.Releases.Arguments;
using FRED.API.Series.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.ReleaseId
{
	[TestClass]
	public class ReleaseSeriesTest : TestBase
	{
		[TestMethod]
		public void ReleaseSeries_InvalidReleaseId_ToolkitValidation()
		{
			Test<ReleaseSeries, ReleaseSeriesArguments, SeriesContainer>(
			(arguments) =>
			{
            },
			AssertInvalidReleaseId_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseSeries_ValidReleaseId_ToolkitValidation()
		{
			Test<ReleaseSeries, ReleaseSeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseSeries_InvalidReleaseId_FREDValidation()
		{
			Test<ReleaseSeries, ReleaseSeriesArguments, SeriesContainer>(
			(arguments) =>
			{
			},
			AssertInvalidReleaseId_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleaseSeries_ValidReleaseId_FREDValidation()
		{
			Test<ReleaseSeries, ReleaseSeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
