﻿using FRED.API.Releases.APIFacades;
using FRED.API.Releases.Arguments;
using FRED.API.Releases.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.ReleaseId
{
	[TestClass]
	public class ReleaseTest : TestBase
	{
		[TestMethod]
		public void Release_InvalidReleaseId_ToolkitValidation()
		{
			Test<Release, ReleaseArguments, ReleaseContainer>(
			(arguments) =>
			{
            },
			AssertInvalidReleaseId_ToolkitValidation);
		}

		[TestMethod]
		public void Release_ValidReleaseId_ToolkitValidation()
		{
			Test<Release, ReleaseArguments, ReleaseContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void Release_InvalidReleaseId_FREDValidation()
		{
			Test<Release, ReleaseArguments, ReleaseContainer>(
			(arguments) =>
			{
			},
			AssertInvalidReleaseId_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void Release_ValidReleaseId_FREDValidation()
		{
			Test<Release, ReleaseArguments, ReleaseContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
