﻿using FRED.API.Releases.APIFacades;
using FRED.API.Releases.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.ReleaseId
{
	[TestClass]
	public class ReleaseRelatedTagsTest : TestBase
	{
		[TestMethod]
		public void ReleaseRelatedTags_InvalidReleaseId_ToolkitValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "sa;foreign";
			},
			AssertInvalidReleaseId_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseRelatedTags_ValidReleaseId_ToolkitValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.tag_names = "sa;foreign";
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseRelatedTags_InvalidReleaseId_FREDValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "sa;foreign";
			},
			AssertInvalidReleaseId_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleaseRelatedTags_ValidReleaseId_FREDValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.tag_names = "sa;foreign";
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
