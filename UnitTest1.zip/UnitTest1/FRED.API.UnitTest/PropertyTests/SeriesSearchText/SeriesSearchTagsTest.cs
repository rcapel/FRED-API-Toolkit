﻿using FRED.API.Series.APIFacades;
using FRED.API.Series.Arguments;
using FRED.API.Series.Data;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.SeriesSearchText
{
	[TestClass]
	public class SeriesSearchTagsTest : TestBase
	{
		[TestMethod]
		public void SeriesSearchTagsText_InvalidSearchText_ToolkitValidation()
		{
			Test<SeriesSearchTags, SeriesSearchTagsArguments, TagContainer>(
			(arguments) =>
			{
			},
			AssertInvalidSeriesSearchText_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearchTags_ValidSearchText_ToolkitValidation()
		{
			Test<SeriesSearchTags, SeriesSearchTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_search_text = "monetary+service+index";
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearchTags_InvalidSearchText_FREDValidation()
		{
			Test<SeriesSearchTags, SeriesSearchTagsArguments, TagContainer>(
			(arguments) =>
			{
			},
			AssertInvalidSeriesSearchText_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesSearchTags_ValidSearchText_FREDValidation()
		{
			Test<SeriesSearchTags, SeriesSearchTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_search_text = "monetary+service+index";
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
