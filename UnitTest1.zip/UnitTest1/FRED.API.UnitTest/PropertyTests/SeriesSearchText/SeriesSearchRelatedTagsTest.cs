﻿using FRED.API.Series.APIFacades;
using FRED.API.Series.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.SeriesSearchText
{
	[TestClass]
	public class SeriesSearchRelatedTagsTest : TestBase
	{
		[TestMethod]
		public void SeriesSearchRelatedTagsText_InvalidSearchText_ToolkitValidation()
		{
			Test<SeriesSearchRelatedTags, SeriesSearchRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "30-year;frb";
			},
			AssertInvalidSeriesSearchText_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearchRelatedTags_ValidSearchText_ToolkitValidation()
		{
			Test<SeriesSearchRelatedTags, SeriesSearchRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "30-year;frb";
				arguments.series_search_text = "mortgage+rate";
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearchRelatedTags_InvalidSearchText_FREDValidation()
		{
			Test<SeriesSearchRelatedTags, SeriesSearchRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "30-year;frb";
			},
			AssertInvalidSeriesSearchText_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesSearchRelatedTags_ValidSearchText_FREDValidation()
		{
			Test<SeriesSearchRelatedTags, SeriesSearchRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "30-year;frb";
				arguments.series_search_text = "mortgage+rate";
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
