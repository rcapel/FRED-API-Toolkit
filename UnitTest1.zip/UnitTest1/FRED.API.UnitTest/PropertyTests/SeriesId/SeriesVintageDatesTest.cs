﻿using FRED.API.Series.APIFacades;
using FRED.API.Series.Arguments;
using FRED.API.Series.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.SeriesId
{
	[TestClass]
	public class SeriesVintageDatesTest : TestBase
	{
		[TestMethod]
		public void SeriesVintageDates_InvalidSeriesId_ToolkitValidation()
		{
			Test<SeriesVintageDates, SeriesVintageDatesArguments, VintageDateContainer>(
			(arguments) =>
			{
            },
			AssertInvalidSeriesId_ToolkitValidation);
		}

		[TestMethod]
		public void Series_ValidSeriesId_ToolkitValidation()
		{
			Test<SeriesVintageDates, SeriesVintageDatesArguments, VintageDateContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void Series_InvalidSeriesId_FREDValidation()
		{
			Test<SeriesVintageDates, SeriesVintageDatesArguments, VintageDateContainer>(
			(arguments) =>
			{
			},
			AssertInvalidSeriesId_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void Series_ValidSeriesId_FREDValidation()
		{
			Test<SeriesVintageDates, SeriesVintageDatesArguments, VintageDateContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
