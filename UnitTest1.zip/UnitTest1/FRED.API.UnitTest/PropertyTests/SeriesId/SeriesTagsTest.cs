﻿using FRED.API.Series.APIFacades;
using FRED.API.Series.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.SeriesId
{
	[TestClass]
	public class SeriesTagsTest : TestBase
	{
		[TestMethod]
		public void SeriesTags_InvalidSeriesId_ToolkitValidation()
		{
			Test<SeriesTags, SeriesTagsArguments, TagContainer>(
			(arguments) =>
			{
            },
			AssertInvalidSeriesId_ToolkitValidation);
		}

		[TestMethod]
		public void Series_ValidSeriesId_ToolkitValidation()
		{
			Test<SeriesTags, SeriesTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void Series_InvalidSeriesId_FREDValidation()
		{
			Test<SeriesTags, SeriesTagsArguments, TagContainer>(
			(arguments) =>
			{
			},
			AssertInvalidSeriesId_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void Series_ValidSeriesId_FREDValidation()
		{
			Test<SeriesTags, SeriesTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
