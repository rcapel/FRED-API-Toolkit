﻿using FRED.API.Categories.Data;
using FRED.API.Series.APIFacades;
using FRED.API.Series.Arguments;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.SeriesId
{
	[TestClass]
	public class SeriesCategoriesTest : TestBase
	{
		[TestMethod]
		public void SeriesCategories_InvalidSeriesId_ToolkitValidation()
		{
			Test<SeriesCategories, SeriesCategoriesArguments, CategoryContainer>(
			(arguments) =>
			{
            },
			AssertInvalidSeriesId_ToolkitValidation);
		}

		[TestMethod]
		public void Series_ValidSeriesId_ToolkitValidation()
		{
			Test<SeriesCategories, SeriesCategoriesArguments, CategoryContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void Series_InvalidSeriesId_FREDValidation()
		{
			Test<SeriesCategories, SeriesCategoriesArguments, CategoryContainer>(
			(arguments) =>
			{
			},
			AssertInvalidSeriesId_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void Series_ValidSeriesId_FREDValidation()
		{
			Test<SeriesCategories, SeriesCategoriesArguments, CategoryContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
