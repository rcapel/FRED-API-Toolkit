﻿using FRED.API.Releases.APIFacades;
using FRED.API.Releases.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.TagNames
{
	[TestClass]
	public class ReleaseRelatedTagsTest : TestBase
	{
		[TestMethod]
		public void ReleaseRelatedTags_InvalidTagNames_ToolkitValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 86;
            },
			AssertInvalidTagNames_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseRelatedTags_ValidTagNames_ToolkitValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 86;
				arguments.tag_names = "services;quarterly";
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseRelatedTags_InvalidTagNames_FREDValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 86;
			},
			AssertInvalidTagNames_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleaseRelatedTags_ValidTagNames_FREDValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 86;
				arguments.tag_names = "services;quarterly";
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
