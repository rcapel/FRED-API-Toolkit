﻿using FRED.API.Categories.APIFacades;
using FRED.API.Categories.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.TagNames
{
	[TestClass]
	public class CategoryRelatedTagsTest : TestBase
	{
		[TestMethod]
		public void CategoryRelatedTags_InvalidTagNames_ToolkitValidation()
		{
			Test<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
            },
			AssertInvalidTagNames_ToolkitValidation);
		}

		[TestMethod]
		public void CategoryRelatedTags_ValidTagNames_ToolkitValidation()
		{
			Test<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services;quarterly";
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void CategoryRelatedTags_InvalidTagNames_FREDValidation()
		{
			Test<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
			},
			AssertInvalidTagNames_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void CategoryRelatedTags_ValidTagNames_FREDValidation()
		{
			Test<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services;quarterly";
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
