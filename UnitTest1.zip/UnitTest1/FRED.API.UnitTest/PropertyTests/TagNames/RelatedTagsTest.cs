﻿using FRED.API.Tags.APIFacades;
using FRED.API.Tags.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.TagNames
{
	[TestClass]
	public class RelatedTagsTest : TestBase
	{
		[TestMethod]
		public void RelatedTags_InvalidTagNames_ToolkitValidation()
		{
			Test<RelatedTags, RelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
            },
			AssertInvalidTagNames_ToolkitValidation);
		}

		[TestMethod]
		public void RelatedTags_ValidTagNames_ToolkitValidation()
		{
			Test<RelatedTags, RelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services;quarterly";
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void RelatedTags_InvalidTagNames_FREDValidation()
		{
			Test<RelatedTags, RelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
			},
			AssertInvalidTagNames_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void RelatedTags_ValidTagNames_FREDValidation()
		{
			Test<RelatedTags, RelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services;quarterly";
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
