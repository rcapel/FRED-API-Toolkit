﻿using FRED.API.Releases.APIFacades;
using FRED.API.Releases.Arguments;
using FRED.API.Series.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Limit
{
	[TestClass]
	public class ReleaseSeriesTest : TestBase
	{
		[TestMethod]
		public void ReleaseSeries_InvalidMinimumLimit_ToolkitValidation()
		{
			Test<ReleaseSeries, ReleaseSeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseSeries_InvalidMaximumLimit_ToolkitValidation()
		{
			Test<ReleaseSeries, ReleaseSeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseSeries_ValidMinimumLimit_ToolkitValidation()
		{
			Test<ReleaseSeries, ReleaseSeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseSeries_ValidMaximumLimit_ToolkitValidation()
		{
			Test<ReleaseSeries, ReleaseSeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseSeries_InvalidMinimumLimit_FREDValidation()
		{
			Test<ReleaseSeries, ReleaseSeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleaseSeries_InvalidMaximumLimit_FREDValidation()
		{
			Test<ReleaseSeries, ReleaseSeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = InvalidMaximumLimit;
            },
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleaseSeries_ValidMinimumLimit_FREDValidation()
		{
			Test<ReleaseSeries, ReleaseSeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleaseSeries_ValidMaximumLimit_FREDValidation()
		{
			Test<ReleaseSeries, ReleaseSeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
