﻿using FRED.API.Sources.Arguments;
using FRED.API.Sources.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Limit
{
	[TestClass]
	public class SourcesTest : TestBase
	{
		[TestMethod]
		public void Sources_InvalidMinimumLimit_ToolkitValidation()
		{
			Test<Sources.APIFacades.Sources, SourcesArguments, SourcesContainer>(
			(arguments) =>
			{
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void Sources_InvalidMaximumLimit_ToolkitValidation()
		{
			Test<Sources.APIFacades.Sources, SourcesArguments, SourcesContainer>(
			(arguments) =>
			{
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void Sources_ValidMinimumLimit_ToolkitValidation()
		{
			Test<Sources.APIFacades.Sources, SourcesArguments, SourcesContainer>(
			(arguments) =>
			{
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void Sources_ValidMaximumLimit_ToolkitValidation()
		{
			Test<Sources.APIFacades.Sources, SourcesArguments, SourcesContainer>(
			(arguments) =>
			{
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void Sources_InvalidMinimumLimit_FREDValidation()
		{
			Test<Sources.APIFacades.Sources, SourcesArguments, SourcesContainer>(
			(arguments) =>
			{
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void Sources_InvalidMaximumLimit_FREDValidation()
		{
			Test<Sources.APIFacades.Sources, SourcesArguments, SourcesContainer>(
			(arguments) =>
			{
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void Sources_ValidMinimumLimit_FREDValidation()
		{
			Test<Sources.APIFacades.Sources, SourcesArguments, SourcesContainer>(
			(arguments) =>
			{
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void Sources_ValidMaximumLimit_FREDValidation()
		{
			Test<Sources.APIFacades.Sources, SourcesArguments, SourcesContainer>(
			(arguments) =>
			{
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
