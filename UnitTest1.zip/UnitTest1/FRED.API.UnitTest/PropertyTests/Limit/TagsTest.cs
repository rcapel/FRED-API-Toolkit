﻿using FRED.API.Tags.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Limit
{
	[TestClass]
	public class TagsTest : TestBase
	{
		[TestMethod]
		public void Tags_InvalidMinimumLimit_ToolkitValidation()
		{
			Test<Tags.APIFacades.Tags, TagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void Tags_InvalidMaximumLimit_ToolkitValidation()
		{
			Test<Tags.APIFacades.Tags, TagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void Tags_ValidMinimumLimit_ToolkitValidation()
		{
			Test<Tags.APIFacades.Tags, TagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void Tags_ValidMaximumLimit_ToolkitValidation()
		{
			Test<Tags.APIFacades.Tags, TagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void Tags_InvalidMinimumLimit_FREDValidation()
		{
			Test<Tags.APIFacades.Tags, TagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void Tags_InvalidMaximumLimit_FREDValidation()
		{
			Test<Tags.APIFacades.Tags, TagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void Tags_ValidMinimumLimit_FREDValidation()
		{
			Test<Tags.APIFacades.Tags, TagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void Tags_ValidMaximumLimit_FREDValidation()
		{
			Test<Tags.APIFacades.Tags, TagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
