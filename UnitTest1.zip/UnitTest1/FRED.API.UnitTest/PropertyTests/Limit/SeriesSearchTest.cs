﻿using FRED.API.Series.APIFacades;
using FRED.API.Series.Arguments;
using FRED.API.Series.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Limit
{
	[TestClass]
	public class SeriesSearchTest : TestBase
	{
		[TestMethod]
		public void SeriesSearch_InvalidMinimumLimit_ToolkitValidation()
		{
			Test<SeriesSearch, SeriesSearchArguments, SeriesSearchContainer>(
			(arguments) =>
			{
				arguments.search_text = "monetary+service+index";
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearch_InvalidMaximumLimit_ToolkitValidation()
		{
			Test<SeriesSearch, SeriesSearchArguments, SeriesSearchContainer>(
			(arguments) =>
			{
				arguments.search_text = "monetary+service+index";
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearch_ValidMinimumLimit_ToolkitValidation()
		{
			Test<SeriesSearch, SeriesSearchArguments, SeriesSearchContainer>(
			(arguments) =>
			{
				arguments.search_text = "monetary+service+index";
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearch_ValidMaximumLimit_ToolkitValidation()
		{
			Test<SeriesSearch, SeriesSearchArguments, SeriesSearchContainer>(
			(arguments) =>
			{
				arguments.search_text = "monetary+service+index";
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearch_InvalidMinimumLimit_FREDValidation()
		{
			Test<SeriesSearch, SeriesSearchArguments, SeriesSearchContainer>(
			(arguments) =>
			{
				arguments.search_text = "monetary+service+index";
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesSearch_InvalidMaximumLimit_FREDValidation()
		{
			Test<SeriesSearch, SeriesSearchArguments, SeriesSearchContainer>(
			(arguments) =>
			{
				arguments.search_text = "monetary+service+index";
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesSearch_ValidMinimumLimit_FREDValidation()
		{
			Test<SeriesSearch, SeriesSearchArguments, SeriesSearchContainer>(
			(arguments) =>
			{
				arguments.search_text = "monetary+service+index";
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesSearch_ValidMaximumLimit_FREDValidation()
		{
			Test<SeriesSearch, SeriesSearchArguments, SeriesSearchContainer>(
			(arguments) =>
			{
				arguments.search_text = "monetary+service+index";
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
