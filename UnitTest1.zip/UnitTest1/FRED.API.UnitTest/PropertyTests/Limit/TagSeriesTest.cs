﻿using FRED.API.Tags.APIFacades;
using FRED.API.Tags.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Limit
{
	[TestClass]
	public class TagSeriesTest : TestBase
	{
		[TestMethod]
		public void TagSeries_InvalidMinimumLimit_ToolkitValidation()
		{
			Test<TagsSeries, TagsSeriesArguments, TagSeriesContainer>(
			(arguments) =>
			{
				arguments.tag_names = "slovenia;food;oecd";
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void TagSeries_InvalidMaximumLimit_ToolkitValidation()
		{
			Test<TagsSeries, TagsSeriesArguments, TagSeriesContainer>(
			(arguments) =>
			{
				arguments.tag_names = "slovenia;food;oecd";
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void TagSeries_ValidMinimumLimit_ToolkitValidation()
		{
			Test<TagsSeries, TagsSeriesArguments, TagSeriesContainer>(
			(arguments) =>
			{
				arguments.tag_names = "slovenia;food;oecd";
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void TagSeries_ValidMaximumLimit_ToolkitValidation()
		{
			Test<TagsSeries, TagsSeriesArguments, TagSeriesContainer>(
			(arguments) =>
			{
				arguments.tag_names = "slovenia;food;oecd";
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void TagSeries_InvalidMinimumLimit_FREDValidation()
		{
			Test<TagsSeries, TagsSeriesArguments, TagSeriesContainer>(
			(arguments) =>
			{
				arguments.tag_names = "slovenia;food;oecd";
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void TagSeries_InvalidMaximumLimit_FREDValidation()
		{
			Test<TagsSeries, TagsSeriesArguments, TagSeriesContainer>(
			(arguments) =>
			{
				arguments.tag_names = "slovenia;food;oecd";
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void TagSeries_ValidMinimumLimit_FREDValidation()
		{
			Test<TagsSeries, TagsSeriesArguments, TagSeriesContainer>(
			(arguments) =>
			{
				arguments.tag_names = "slovenia;food;oecd";
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void TagSeries_ValidMaximumLimit_FREDValidation()
		{
			Test<TagsSeries, TagsSeriesArguments, TagSeriesContainer>(
			(arguments) =>
			{
				arguments.tag_names = "slovenia;food;oecd";
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
