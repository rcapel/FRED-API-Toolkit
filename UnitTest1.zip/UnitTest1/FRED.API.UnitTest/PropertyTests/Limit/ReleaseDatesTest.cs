﻿using FRED.API.Releases.APIFacades;
using FRED.API.Releases.Arguments;
using FRED.API.Releases.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Limit
{
	[TestClass]
	public class ReleaseDatesTest : TestBase
	{
		[TestMethod]
		public void ReleaseDates_InvalidMinimumLimit_ToolkitValidation()
		{
			Test<ReleaseDates, ReleaseDatesArguments, ReleaseDateContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseDates_InvalidMaximumLimit_ToolkitValidation()
		{
			Test<ReleaseDates, ReleaseDatesArguments, ReleaseDateContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = 10001;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseDates_ValidMinimumLimit_ToolkitValidation()
		{
			Test<ReleaseDates, ReleaseDatesArguments, ReleaseDateContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseDates_ValidMaximumLimit_ToolkitValidation()
		{
			Test<ReleaseDates, ReleaseDatesArguments, ReleaseDateContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = 10000;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseDates_InvalidMinimumLimit_FREDValidation()
		{
			Test<ReleaseDates, ReleaseDatesArguments, ReleaseDateContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit10000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleaseDates_InvalidMaximumLimit_FREDValidation()
		{
			Test<ReleaseDates, ReleaseDatesArguments, ReleaseDateContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = 10001;
			},
			AssertInvalidLimit10000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleaseDates_ValidMinimumLimit_FREDValidation()
		{
			Test<ReleaseDates, ReleaseDatesArguments, ReleaseDateContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleaseDates_ValidMaximumLimit_FREDValidation()
		{
			Test<ReleaseDates, ReleaseDatesArguments, ReleaseDateContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = 10000;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
