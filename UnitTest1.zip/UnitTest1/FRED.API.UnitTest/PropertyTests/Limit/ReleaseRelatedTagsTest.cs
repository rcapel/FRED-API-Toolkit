﻿using FRED.API.Releases.APIFacades;
using FRED.API.Releases.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Limit
{
	[TestClass]
	public class ReleaseRelatedTagsTest : TestBase
	{
		[TestMethod]
		public void ReleaseRelatedTags_InvalidMinimumLimit_ToolkitValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.tag_names = "sa;foreign";
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseRelatedTags_InvalidMaximumLimit_ToolkitValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.tag_names = "sa;foreign";
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseRelatedTags_ValidMinimumLimit_ToolkitValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.tag_names = "sa;foreign";
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseRelatedTags_ValidMaximumLimit_ToolkitValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.tag_names = "sa;foreign";
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseRelatedTags_InvalidMinimumLimit_FREDValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.tag_names = "sa;foreign";
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleaseRelatedTags_InvalidMaximumLimit_FREDValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.tag_names = "sa;foreign";
				arguments.limit = InvalidMaximumLimit;
            },
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleaseRelatedTags_ValidMinimumLimit_FREDValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.tag_names = "sa;foreign";
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleaseRelatedTags_ValidMaximumLimit_FREDValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.tag_names = "sa;foreign";
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
