﻿using FRED.API.Releases.APIFacades;
using FRED.API.Releases.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Limit
{
	[TestClass]
	public class ReleaseTagsTest : TestBase
	{
		[TestMethod]
		public void ReleaseTags_InvalidMinimumLimit_ToolkitValidation()
		{
			Test<ReleaseTags, ReleaseTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseTags_InvalidMaximumLimit_ToolkitValidation()
		{
			Test<ReleaseTags, ReleaseTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseTags_ValidMinimumLimit_ToolkitValidation()
		{
			Test<ReleaseTags, ReleaseTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseTags_ValidMaximumLimit_ToolkitValidation()
		{
			Test<ReleaseTags, ReleaseTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseTags_InvalidMinimumLimit_FREDValidation()
		{
			Test<ReleaseTags, ReleaseTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleaseTags_InvalidMaximumLimit_FREDValidation()
		{
			Test<ReleaseTags, ReleaseTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = InvalidMaximumLimit;
            },
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleaseTags_ValidMinimumLimit_FREDValidation()
		{
			Test<ReleaseTags, ReleaseTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleaseTags_ValidMaximumLimit_FREDValidation()
		{
			Test<ReleaseTags, ReleaseTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
