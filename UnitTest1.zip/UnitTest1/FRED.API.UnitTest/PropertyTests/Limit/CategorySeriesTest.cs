﻿using FRED.API.Categories.APIFacades;
using FRED.API.Categories.Arguments;
using FRED.API.Series.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Limit
{
	[TestClass]
	public class CategorySeriesTest : TestBase
	{
		[TestMethod]
		public void CategorySeries_InvalidMinimumLimit_ToolkitValidation()
		{
			Test<CategorySeries, CategorySeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void CategorySeries_InvalidMaximumLimit_ToolkitValidation()
		{
			Test<CategorySeries, CategorySeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void CategorySeries_ValidMinimumLimit_ToolkitValidation()
		{
			Test<CategorySeries, CategorySeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void CategorySeries_ValidMaximumLimit_ToolkitValidation()
		{
			Test<CategorySeries, CategorySeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void CategorySeries_InvalidMinimumLimit_FREDValidation()
		{
			Test<CategorySeries, CategorySeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void CategorySeries_InvalidMaximumLimit_FREDValidation()
		{
			Test<CategorySeries, CategorySeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void CategorySeries_ValidMinimumLimit_FREDValidation()
		{
			Test<CategorySeries, CategorySeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void CategorySeries_ValidMaximumLimit_FREDValidation()
		{
			Test<CategorySeries, CategorySeriesArguments, SeriesContainer>(
			(arguments) =>
			{
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
