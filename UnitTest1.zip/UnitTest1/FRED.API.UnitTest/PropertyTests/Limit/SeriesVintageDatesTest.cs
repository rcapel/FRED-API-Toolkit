﻿using FRED.API.Series.APIFacades;
using FRED.API.Series.Arguments;
using FRED.API.Series.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Limit
{
	[TestClass]
	public class SeriesVintageDatesTest : TestBase
	{
		[TestMethod]
		public void SeriesVintageDates_InvalidMinimumLimit_ToolkitValidation()
		{
			Test<SeriesVintageDates, SeriesVintageDatesArguments, VintageDateContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesVintageDates_InvalidMaximumLimit_ToolkitValidation()
		{
			Test<SeriesVintageDates, SeriesVintageDatesArguments, VintageDateContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.limit = 10001;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesVintageDates_ValidMinimumLimit_ToolkitValidation()
		{
			Test<SeriesVintageDates, SeriesVintageDatesArguments, VintageDateContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesVintageDates_ValidMaximumLimit_ToolkitValidation()
		{
			Test<SeriesVintageDates, SeriesVintageDatesArguments, VintageDateContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.limit = 10000;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesVintageDates_InvalidMinimumLimit_FREDValidation()
		{
			Test<SeriesVintageDates, SeriesVintageDatesArguments, VintageDateContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit10000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesVintageDates_InvalidMaximumLimit_FREDValidation()
		{
			Test<SeriesVintageDates, SeriesVintageDatesArguments, VintageDateContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.limit = 10001;
			},
			AssertInvalidLimit10000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesVintageDates_ValidMinimumLimit_FREDValidation()
		{
			Test<SeriesVintageDates, SeriesVintageDatesArguments, VintageDateContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesVintageDates_ValidMaximumLimit_FREDValidation()
		{
			Test<SeriesVintageDates, SeriesVintageDatesArguments, VintageDateContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.limit = 10000;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
