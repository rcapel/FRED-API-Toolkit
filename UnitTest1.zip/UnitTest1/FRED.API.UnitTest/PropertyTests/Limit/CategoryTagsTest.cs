﻿using FRED.API.Categories.APIFacades;
using FRED.API.Categories.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Limit
{
	[TestClass]
	public class CategoryTagsTest : TestBase
	{
		[TestMethod]
		public void CategoryTags_InvalidMinimumLimit_ToolkitValidation()
		{
			Test<CategoryTags, CategoryTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void CategoryTags_InvalidMaximumLimit_ToolkitValidation()
		{
			Test<CategoryTags, CategoryTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void CategoryTags_ValidMinimumLimit_ToolkitValidation()
		{
			Test<CategoryTags, CategoryTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void CategoryTags_ValidMaximumLimit_ToolkitValidation()
		{
			Test<CategoryTags, CategoryTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void CategoryTags_InvalidMinimumLimit_FREDValidation()
		{
			Test<CategoryTags, CategoryTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void CategoryTags_InvalidMaximumLimit_FREDValidation()
		{
			Test<CategoryTags, CategoryTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void CategoryTags_ValidMinimumLimit_FREDValidation()
		{
			Test<CategoryTags, CategoryTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void CategoryTags_ValidMaximumLimit_FREDValidation()
		{
			Test<CategoryTags, CategoryTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
