﻿using FRED.API.Tags.APIFacades;
using FRED.API.Tags.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Limit
{
	[TestClass]
	public class RelatedTagsTest : TestBase
	{
		[TestMethod]
		public void RelatedTags_InvalidMinimumLimit_ToolkitValidation()
		{
			Test<RelatedTags, RelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "monetary+aggregates;weekly";
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void RelatedTags_InvalidMaximumLimit_ToolkitValidation()
		{
			Test<RelatedTags, RelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "monetary+aggregates;weekly";
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void RelatedTags_ValidMinimumLimit_ToolkitValidation()
		{
			Test<RelatedTags, RelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "monetary+aggregates;weekly";
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void RelatedTags_ValidMaximumLimit_ToolkitValidation()
		{
			Test<RelatedTags, RelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "monetary+aggregates;weekly";
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void RelatedTags_InvalidMinimumLimit_FREDValidation()
		{
			Test<RelatedTags, RelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "monetary+aggregates;weekly";
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void RelatedTags_InvalidMaximumLimit_FREDValidation()
		{
			Test<RelatedTags, RelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "monetary+aggregates;weekly";
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void RelatedTags_ValidMinimumLimit_FREDValidation()
		{
			Test<RelatedTags, RelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "monetary+aggregates;weekly";
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void RelatedTags_ValidMaximumLimit_FREDValidation()
		{
			Test<RelatedTags, RelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "monetary+aggregates;weekly";
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
