﻿using FRED.API.Categories.APIFacades;
using FRED.API.Categories.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Limit
{
	[TestClass]
	public class CategoryRelatedTagsTest : TestBase
	{
		[TestMethod]
		public void CategoryRelatedTags_InvalidMinimumLimit_ToolkitValidation()
		{
			Test<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services;quarterly";
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void CategoryRelatedTags_InvalidMaximumLimit_ToolkitValidation()
		{
			Test<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services;quarterly";
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void CategoryRelatedTags_ValidMinimumLimit_ToolkitValidation()
		{
			Test<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services;quarterly";
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void CategoryRelatedTags_ValidMaximumLimit_ToolkitValidation()
		{
			Test<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services;quarterly";
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void CategoryRelatedTags_InvalidMinimumLimit_FREDValidation()
		{
			Test<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services;quarterly";
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void CategoryRelatedTags_InvalidMaximumLimit_FREDValidation()
		{
			Test<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services;quarterly";
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void CategoryRelatedTags_ValidMinimumLimit_FREDValidation()
		{
			Test<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services;quarterly";
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void CategoryRelatedTags_ValidMaximumLimit_FREDValidation()
		{
			Test<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services;quarterly";
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
