﻿using FRED.API.Series.APIFacades;
using FRED.API.Series.Arguments;
using FRED.API.Series.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.SearchText
{
	[TestClass]
	public class SeriesSearchTest : TestBase
	{
		[TestMethod]
		public void SeriesSearch_InvalidSearchText_ToolkitValidation()
		{
			Test<SeriesSearch, SeriesSearchArguments, SeriesSearchContainer>(
			(arguments) =>
			{
			},
			AssertInvalidSearchText_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearch_ValidSearchText_ToolkitValidation()
		{
			Test<SeriesSearch, SeriesSearchArguments, SeriesSearchContainer>(
			(arguments) =>
			{
				arguments.search_text = "monetary+service+index";
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearch_InvalidSearchText_FREDValidation()
		{
			Test<SeriesSearch, SeriesSearchArguments, SeriesSearchContainer>(
			(arguments) =>
			{
			},
			AssertInvalidSearchText_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesSearch_ValidSearchText_FREDValidation()
		{
			Test<SeriesSearch, SeriesSearchArguments, SeriesSearchContainer>(
			(arguments) =>
			{
				arguments.search_text = "monetary+service+index";
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
