﻿using FRED.API.Sources.APIFacades;
using FRED.API.Sources.Arguments;
using FRED.API.Sources.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.SourceId
{
	[TestClass]
	public class SourceReleasesTest : TestBase
	{
		[TestMethod]
		public void SourceReleases_InvalidSourceId_ToolkitValidation()
		{
			Test<SourceReleases, SourceReleasesArguments, SourceReleasesContainer>(
			(arguments) =>
			{
            },
			AssertInvalidSourceId_ToolkitValidation);
		}

		[TestMethod]
		public void SourceReleases_ValidSourceId_ToolkitValidation()
		{
			Test<SourceReleases, SourceReleasesArguments, SourceReleasesContainer>(
			(arguments) =>
			{
				arguments.source_id = 1;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void SourceReleases_InvalidSourceId_FREDValidation()
		{
			Test<SourceReleases, SourceReleasesArguments, SourceReleasesContainer>(
			(arguments) =>
			{
			},
			AssertInvalidSourceId_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SourceReleases_ValidSourceId_FREDValidation()
		{
			Test<SourceReleases, SourceReleasesArguments, SourceReleasesContainer>(
			(arguments) =>
			{
				arguments.source_id = 1;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
