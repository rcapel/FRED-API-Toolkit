﻿using FRED.API.Series.APIFacades;
using FRED.API.Series.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Limit
{
	[TestClass]
	public class SeriesSearchTagsTagsTest : TestBase
	{
		[TestMethod]
		public void SeriesSearchTags_InvalidMinimumLimit_ToolkitValidation()
		{
			Test<SeriesSearchTags, SeriesSearchTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_search_text = "monetary+service+index";
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearchTags_InvalidMaximumLimit_ToolkitValidation()
		{
			Test<SeriesSearchTags, SeriesSearchTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_search_text = "monetary+service+index";
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearchTags_ValidMinimumLimit_ToolkitValidation()
		{
			Test<SeriesSearchTags, SeriesSearchTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_search_text = "monetary+service+index";
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearchTags_ValidMaximumLimit_ToolkitValidation()
		{
			Test<SeriesSearchTags, SeriesSearchTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_search_text = "monetary+service+index";
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearchTags_InvalidMinimumLimit_FREDValidation()
		{
			Test<SeriesSearchTags, SeriesSearchTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_search_text = "monetary+service+index";
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesSearchTags_InvalidMaximumLimit_FREDValidation()
		{
			Test<SeriesSearchTags, SeriesSearchTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_search_text = "monetary+service+index";
				arguments.limit = InvalidMaximumLimit;
			},
			AssertInvalidLimit1000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesSearchTags_ValidMinimumLimit_FREDValidation()
		{
			Test<SeriesSearchTags, SeriesSearchTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_search_text = "monetary+service+index";
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesSearchTags_ValidMaximumLimit_FREDValidation()
		{
			Test<SeriesSearchTags, SeriesSearchTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_search_text = "monetary+service+index";
				arguments.limit = ValidMaximumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
