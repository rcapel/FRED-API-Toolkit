﻿using FRED.API.Series.APIFacades;
using FRED.API.Series.Arguments;
using FRED.API.Series.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Limit
{
	[TestClass]
	public class SeriesObservationsTest : TestBase
	{
		[TestMethod]
		public void SeriesObservations_InvalidMinimumLimit_ToolkitValidation()
		{
			Test<SeriesObservations, SeriesObservationsArguments, ObservationContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesObservations_InvalidMaximumLimit_ToolkitValidation()
		{
			Test<SeriesObservations, SeriesObservationsArguments, ObservationContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.limit = 100001;
			},
			AssertInvalidLimit_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesObservations_ValidMinimumLimit_ToolkitValidation()
		{
			Test<SeriesObservations, SeriesObservationsArguments, ObservationContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesObservations_ValidMaximumLimit_ToolkitValidation()
		{
			Test<SeriesObservations, SeriesObservationsArguments, ObservationContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.limit = 100000;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesObservations_InvalidMinimumLimit_FREDValidation()
		{
			Test<SeriesObservations, SeriesObservationsArguments, ObservationContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.limit = InvalidMinimumLimit;
			},
			AssertInvalidLimit100000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesObservations_InvalidMaximumLimit_FREDValidation()
		{
			Test<SeriesObservations, SeriesObservationsArguments, ObservationContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.limit = 100001;
			},
			AssertInvalidLimit100000_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesObservations_ValidMinimumLimit_FREDValidation()
		{
			Test<SeriesObservations, SeriesObservationsArguments, ObservationContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.limit = ValidMinimumLimit;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesObservations_ValidMaximumLimit_FREDValidation()
		{
			Test<SeriesObservations, SeriesObservationsArguments, ObservationContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.limit = 100000;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
