﻿using FRED.API.Series.APIFacades;
using FRED.API.Series.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.TagNames
{
	[TestClass]
	public class SeriesSearchRelatedTagsTest : TestBase
	{
		[TestMethod]
		public void SeriesSearchRelatedTags_InvalidTagNames_ToolkitValidation()
		{
			Test<SeriesSearchRelatedTags, SeriesSearchRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_search_text = "mortgage+rate";
			},
			AssertInvalidTagNames_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearchRelatedTags_ValidTagNames_ToolkitValidation()
		{
			Test<SeriesSearchRelatedTags, SeriesSearchRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_search_text = "mortgage+rate";
				arguments.tag_names = "services;quarterly";
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesSearchRelatedTags_InvalidTagNames_FREDValidation()
		{
			Test<SeriesSearchRelatedTags, SeriesSearchRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_search_text = "mortgage+rate";
			},
			AssertInvalidTagNames_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesSearchRelatedTags_ValidTagNames_FREDValidation()
		{
			Test<SeriesSearchRelatedTags, SeriesSearchRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.series_search_text = "mortgage+rate";
				arguments.tag_names = "services;quarterly";
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
