﻿using FRED.API.Releases.APIFacades;
using FRED.API.Releases.Arguments;
using FRED.API.Sources.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.ReleaseId
{
	[TestClass]
	public class ReleaseSourcesTest : TestBase
	{
		[TestMethod]
		public void ReleaseSources_InvalidReleaseId_ToolkitValidation()
		{
			Test<ReleaseSources, ReleaseSourcesArguments, SourceContainer>(
			(arguments) =>
			{
            },
			AssertInvalidReleaseId_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseSources_ValidReleaseId_ToolkitValidation()
		{
			Test<ReleaseSources, ReleaseSourcesArguments, SourceContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseSources_InvalidReleaseId_FREDValidation()
		{
			Test<ReleaseSources, ReleaseSourcesArguments, SourceContainer>(
			(arguments) =>
			{
			},
			AssertInvalidReleaseId_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleaseSources_ValidReleaseId_FREDValidation()
		{
			Test<ReleaseSources, ReleaseSourcesArguments, SourceContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
