﻿using FRED.API.Releases.APIFacades;
using FRED.API.Releases.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.ReleaseId
{
	[TestClass]
	public class ReleaseTagsTest : TestBase
	{
		[TestMethod]
		public void ReleaseTags_InvalidReleaseId_ToolkitValidation()
		{
			Test<ReleaseTags, ReleaseTagsArguments, TagContainer>(
			(arguments) =>
			{
            },
			AssertInvalidReleaseId_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseTags_ValidReleaseId_ToolkitValidation()
		{
			Test<ReleaseTags, ReleaseTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void ReleaseTags_InvalidReleaseId_FREDValidation()
		{
			Test<ReleaseTags, ReleaseTagsArguments, TagContainer>(
			(arguments) =>
			{
			},
			AssertInvalidReleaseId_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleaseTags_ValidReleaseId_FREDValidation()
		{
			Test<ReleaseTags, ReleaseTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
