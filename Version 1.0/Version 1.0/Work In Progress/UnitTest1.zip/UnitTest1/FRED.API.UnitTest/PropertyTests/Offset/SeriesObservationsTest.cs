﻿using FRED.API.Series.APIFacades;
using FRED.API.Series.Arguments;
using FRED.API.Series.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Offset
{
	[TestClass]
	public class SeriesObservationsTest : TestBase
	{
		[TestMethod]
		public void SeriesObservations_InvalidOffset_ToolkitValidation()
		{
			Test<SeriesObservations, SeriesObservationsArguments, ObservationContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesObservations_ValidOffset_ToolkitValidation()
		{
			Test<SeriesObservations, SeriesObservationsArguments, ObservationContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.offset = 0;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void SeriesObservations_InvalidOffset_FREDValidation()
		{
			Test<SeriesObservations, SeriesObservationsArguments, ObservationContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void SeriesObservations_ValidOffset_FREDValidation()
		{
			Test<SeriesObservations, SeriesObservationsArguments, ObservationContainer>(
			(arguments) =>
			{
				arguments.series_id = "GNPCA";
				arguments.offset = 0;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
