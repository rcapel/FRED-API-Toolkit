﻿using FRED.API.Sources.Arguments;
using FRED.API.Sources.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.Offset
{
	[TestClass]
	public class SourcesTest : TestBase
	{
		[TestMethod]
		public void Sources_InvalidOffset_ToolkitValidation()
		{
			Test<Sources.APIFacades.Sources, SourcesArguments, SourcesContainer>(
			(arguments) =>
			{
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_ToolkitValidation);
		}

		[TestMethod]
		public void Sources_ValidOffset_ToolkitValidation()
		{
			Test<Sources.APIFacades.Sources, SourcesArguments, SourcesContainer>(
			(arguments) =>
			{
				arguments.offset = 0;
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void Sources_InvalidOffset_FREDValidation()
		{
			Test<Sources.APIFacades.Sources, SourcesArguments, SourcesContainer>(
			(arguments) =>
			{
				arguments.offset = InvalidOffset;
			},
			AssertInvalidOffset_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void Sources_ValidOffset_FREDValidation()
		{
			Test<Sources.APIFacades.Sources, SourcesArguments, SourcesContainer>(
			(arguments) =>
			{
				arguments.offset = 0;
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
