﻿using FRED.API.Releases.APIFacades;
using FRED.API.Releases.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.TagNamesAndExcludedTagNames
{
	[TestClass]
	public class ReleaseRelatedTagsTest : TestBase
	{
		[TestMethod]
		public void ReleasesRelatedTags_InvalidTagNamesAndExcludedTagNames_ToolkitValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.exclude_tag_names = "quarterly";
			},
			AssertInvalidTagNamesAndExcludedTagNames_ToolkitValidation);
		}

		[TestMethod]
		public void ReleasesRelatedTags_ValidTagNamesAndExcludedTagNames_ToolkitValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.tag_names = "services";
				arguments.exclude_tag_names = "quarterly";
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void ReleasesRelatedTags_InvalidTagNamesAndExcludedTagNames_FREDValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.exclude_tag_names = "quarterly";
			},
			AssertInvalidTagNamesAndExcludedTagNames_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void ReleasesRelatedTags_ValidTagNamesAndExcludedTagNames_FREDValidation()
		{
			Test<ReleaseRelatedTags, ReleaseRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.release_id = 82;
				arguments.tag_names = "services";
				arguments.exclude_tag_names = "quarterly";
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
