﻿using FRED.API.Categories.APIFacades;
using FRED.API.Categories.Arguments;
using FRED.API.Tags.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FRED.API.UnitTest.PropertyTests.TagNamesAndExcludedTagNames
{
	[TestClass]
	public class CategoryRelatedTagsTest : TestBase
	{
		[TestMethod]
		public void CategoryRelatedTags_InvalidTagNamesAndExcludedTagNames_ToolkitValidation()
		{
			Test<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.exclude_tag_names = "quarterly";
			},
			AssertInvalidTagNamesAndExcludedTagNames_ToolkitValidation);
		}

		[TestMethod]
		public void CategoryRelatedTags_ValidTagNamesAndExcludedTagNames_ToolkitValidation()
		{
			Test<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services";
				arguments.exclude_tag_names = "quarterly";
			},
			AssertSuccess_ToolkitValidation);
		}

		[TestMethod]
		public void CategoryRelatedTags_InvalidTagNamesAndExcludedTagNames_FREDValidation()
		{
			Test<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.exclude_tag_names = "quarterly";
			},
			AssertInvalidTagNamesAndExcludedTagNames_FREDValidation,
			clearValidators: true);
		}

		[TestMethod]
		public void CategoryRelatedTags_ValidTagNamesAndExcludedTagNames_FREDValidation()
		{
			Test<CategoryRelatedTags, CategoryRelatedTagsArguments, TagContainer>(
			(arguments) =>
			{
				arguments.tag_names = "services";
				arguments.exclude_tag_names = "quarterly";
			},
			AssertSuccess_FREDValidation,
			clearValidators: true);
		}

	}
}
