﻿namespace FRED.API.Arguments.Validation
{
	public class CategoryId : ValidatorBase
	{
		#region properties

		protected override string Name
		{
			get { return "category_id"; }
		}

		public override string Message
		{
			get { return string.Format("category_id must be between 1 and {1}, inclusive; found {0}", Value, Maximum); }
		}

		protected override bool? Validations
		{
			get { return Value == null || ((int)Value).IsBetween(1, Maximum); }
		}

		#endregion

	}
}
