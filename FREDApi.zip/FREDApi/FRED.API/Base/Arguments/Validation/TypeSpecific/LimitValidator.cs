﻿using FRED.API.Releases.Arguments;

namespace FRED.API.Arguments.Validation.ReleaseDates
{
	public class LimitValidator : Validation.LimitValidator
	{
		#region properties

		protected override int Maximum
		{
			get { return 10000; }
		}

		protected override bool? Validations
		{
			get
			{
				if (Type != typeof(ReleaseDatesArguments))
					return null;

				return true;
			}
		}

		#endregion

	}
}
