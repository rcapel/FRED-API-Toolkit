﻿using FRED.API.Categories.Arguments;
using System;
using System.Collections.Generic;

namespace FRED.API.Arguments.Validation.CategoryRelated
{
	public class Required : Common.Required
	{
		#region properties

		private static readonly List<string> supportedPropertyNames = new List<string> { "category_id" };
		/// <summary>
		/// A list of property names supported by this class.
		/// </summary>
		protected override List<string> SupportedPropertyNames
		{
			get { return supportedPropertyNames; }
		}

		private List<Type> supportedTypes = new List<Type> { typeof(CategoryRelatedArguments) };
		/// <summary>
		/// A list of types supported by this class.
		/// </summary>
		protected override List<Type> SupportedTypes
		{
			get { return supportedTypes; }
		}

		#endregion

	}
}
