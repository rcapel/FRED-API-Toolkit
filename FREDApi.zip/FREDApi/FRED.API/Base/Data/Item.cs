﻿namespace FRED.API.Supporting.Data
{
	/// <summary>
	/// Provides detault data properties for a release. 
	/// </summary>
	public abstract partial class Item : IApiKeyed
	{
		#region properties

		public string ApiKey { get; set; }

		#endregion

	}
}
