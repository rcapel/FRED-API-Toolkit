﻿using FRED.API.Releases.Arguments;
using FRED.API.Sources.Data;
using FRED.API.Base.APIFacades;

namespace FRED.API.Releases.APIFacades
{
	/// <summary>
	/// Provides a facade for consuming the fred/release/sources API endpoint. Results are returned in a SourceContainer instance.
	/// </summary>
	public class ReleaseSources : ApiBase<ReleaseSourcesArguments, SourceContainer>
	{
	}

	/// <summary>
	/// Provides a facade for consuming the fred/release/sources API endpoint. Results are returned as a JSON string.
	/// </summary>
	public class ReleaseSourcesJson : ApiBase<ReleaseSourcesArguments, string>
	{
	}

	/// <summary>
	/// Provides a facade for consuming the fred/release/sources API endpoint. Results are returned as an XML string.
	/// </summary>
	public class ReleaseSourcesXml : XmlApiFacade<ReleaseSourcesArguments>
	{
	}

}
