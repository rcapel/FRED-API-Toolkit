﻿using FRED.API.Releases.Arguments;
using FRED.API.Base.APIFacades;
using FRED.API.Tags.Data;

namespace FRED.API.Releases.APIFacades
{
	/// <summary>
	/// Provides a facade for consuming the fred/release/tags API endpoint. Results are returned in a TagContainer instance.
	/// </summary>
	public class ReleaseTags : ApiBase<ReleaseTagsArguments, TagContainer>
	{
	}

	/// <summary>
	/// Provides a facade for consuming the fred/release/tags API endpoint. Results are returned as a JSON string.
	/// </summary>
	public class ReleaseTagsJson : ApiBase<ReleaseTagsArguments, string>
	{
	}

	/// <summary>
	/// Provides a facade for consuming the fred/release/tags API endpoint. Results are returned as an XML string.
	/// </summary>
	public class ReleaseTagsXml : XmlApiFacade<ReleaseTagsArguments>
	{
	}

}
