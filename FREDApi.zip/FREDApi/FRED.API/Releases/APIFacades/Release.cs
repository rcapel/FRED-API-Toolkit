﻿using FRED.API.Releases.Arguments;
using FRED.API.Releases.Data;
using FRED.API.Base.APIFacades;

namespace FRED.API.Releases.APIFacades
{
	/// <summary>
	/// Provides a facade for consuming the fred/release API endpoint. Results are returned in a ReleaseContainer instance.
	/// </summary>
	public class Release : ApiBase<ReleaseArguments, ReleaseContainer>
	{
	}

	/// <summary>
	/// Provides a facade for consuming the fred/release API endpoint. Results are returned as a JSON string.
	/// </summary>
	public class ReleaseJson : ApiBase<ReleaseArguments, string>
	{
	}

	/// <summary>
	/// Provides a facade for consuming the fred/release API endpoint. Results are returned as an XML string.
	/// </summary>
	public class ReleaseXml : XmlApiFacade<ReleaseArguments>
	{
	}

}
