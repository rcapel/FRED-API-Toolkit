﻿using FRED.API.Releases.Arguments;
using FRED.API.Series.Data;
using FRED.API.Base.APIFacades;

namespace FRED.API.Releases.APIFacades
{
	/// <summary>
	/// Provides a facade for consuming the fred/release/series API endpoint. Results are returned in a SeriesContainer instance.
	/// </summary>
	public class ReleaseSeries : ApiBase<ReleaseSeriesArguments, SeriesContainer>
	{
	}

	/// <summary>
	/// Provides a facade for consuming the fred/release/series API endpoint. Results are returned as a JSON string.
	/// </summary>
	public class ReleaseSeriesJson : ApiBase<ReleaseSeriesArguments, string>
	{
	}

	/// <summary>
	/// Provides a facade for consuming the fred/release/series API endpoint. Results are returned as an XML string.
	/// </summary>
	public class ReleaseSeriesXml : XmlApiFacade<ReleaseSeriesArguments>
	{
	}

}
