﻿using FRED.API.Releases.Arguments;
using FRED.API.Releases.Data;
using FRED.API.Base.APIFacades;

namespace FRED.API.Releases.APIFacades
{
	/// <summary>
	/// Provides a facade for consuming the fred/release/dates API endpoint. Results are returned in a ReleaseDateContainer instance.
	/// </summary>
	public class ReleaseDates : ApiBase<ReleaseDatesArguments, ReleaseDateContainer>
	{
	}

	/// <summary>
	/// Provides a facade for consuming the fred/release/dates API endpoint. Results are returned as a JSON string.
	/// </summary>
	public class ReleaseDatesJson : ApiBase<ReleaseDatesArguments, string>
	{
	}

	/// <summary>
	/// Provides a facade for consuming the fred/release/dates API endpoint. Results are returned as an XML string.
	/// </summary>
	public class ReleaseDatesXml : XmlApiFacade<ReleaseDatesArguments>
	{
	}

}
