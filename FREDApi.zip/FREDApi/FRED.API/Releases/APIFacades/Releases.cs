﻿using FRED.API.Releases.Arguments;
using FRED.API.Releases.Data;
using FRED.API.Base.APIFacades;

namespace FRED.API.Releases.APIFacades
{
	/// <summary>
	/// Provides a facade for consuming the fred/releases API endpoint. Results are returned in a ReleasesContainer instance.
	/// </summary>
	public class Releases : ApiBase<ReleasesArguments, ReleasesContainer>
	{
	}

	/// <summary>
	/// Provides a facade for consuming the fred/releases API endpoint. Results are returned as a JSON string.
	/// </summary>
	public class ReleasesJson : ApiBase<ReleasesArguments, string>
	{
	}

	/// <summary>
	/// Provides a facade for consuming the fred/releases API endpoint. Results are returned as an XML string.
	/// </summary>
	public class ReleasesXml : XmlApiFacade<ReleasesArguments>
	{
	}

}
