﻿using FRED.API.Releases.Arguments;
using FRED.API.Releases.Data;
using FRED.API.Base.APIFacades;

namespace FRED.API.Releases.APIFacades
{
	/// <summary>
	/// Provides a facade for consuming the fred/releases/dates API endpoint. Results are returned in a ReleasesDateContainer instance.
	/// </summary>
	public class ReleasesDates : ApiBase<ReleasesDatesArguments, ReleasesDateContainer>
	{
	}

	/// <summary>
	/// Provides a facade for consuming the fred/releases/dates API endpoint. Results are returned as a JSON string.
	/// </summary>
	public class ReleasesDatesJson : ApiBase<ReleasesDatesArguments, string>
	{
	}

	/// <summary>
	/// Provides a facade for consuming the fred/releases/dates API endpoint. Results are returned as an XML string.
	/// </summary>
	public class ReleasesDatesXml : XmlApiFacade<ReleasesDatesArguments>
	{
	}

}
